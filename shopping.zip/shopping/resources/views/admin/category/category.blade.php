@include('admin.layouts.head')

<div id="wrapper">
    <!-- Navigation -->
    @include('admin.layouts.navbar')

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>

                <a href="/admin/category/add" type="button" class="btn btn-success">Add Product</a>
               <h5></h5>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        DataTables Advanced Tables
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Category Title</th>
                                <th>Category Url</th>
                                <th>Sub Categories</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($categories as $category)
                            <tr>
                                <td>{{$category->id}}</td>
                                <td>{{$category->categoryTitle}}</td>
                                <td>{{$category->categoryUrl}}</td>
                                <td>@foreach($category->subCategory as $subCategory)
                                        <p>Sub Category Name: {{$subCategory->categoryTitle}}</p>
                                        <p>Sub Category Url: {{$subCategory->categoryUrl}}</p>
                                        <a href="/admin/category/delete/{{$subCategory->id}}"
                                           type="button" class="btn btn-warning btn-circle">
                                            <i class="fa fa-times"></i></a>
                                        <br>
                                        @foreach($subCategory->subCategory as $subSubCategory)
                                            <span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span>
                                                <p>Sub Sub Category Name: {{$subSubCategory->categoryTitle}}</p>
                                                <p>Sub Sub Category Url: {{$subSubCategory->categoryUrl}}</p>
                                                <a href="/admin/category/delete/{{$subSubCategory->id}}"
                                                   type="button" class="btn btn-warning btn-circle">
                                                    <i class="fa fa-times"></i></a>
                                                <br>
                                            @endforeach
                                        <br>
                                    @endforeach
                                </td>

                                <td>
                                    <a href="/admin/category/update/{{$category->id}}"
                                       type="button" class="btn btn-info">Update</a>
                                    <a href="/admin/category/delete/{{$category->id}}"
                                       type="button" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            @endforeach
                            </tbody>
                        </table>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
@include('admin.layouts.footer')