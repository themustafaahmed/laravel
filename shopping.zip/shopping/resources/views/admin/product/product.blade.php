@include('admin.layouts.head')

<div id="wrapper">
    <!-- Navigation -->
    @include('admin.layouts.navbar')

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>

                <a href="/admin/product/add" type="button" class="btn btn-success">Add Product</a>
                <h5></h5>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        DataTables Advanced Tables
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>Sale Price</th>
                                <th>In Stock</th>
                                <th>Count</th>
                                <th>Color</th>
                                <th>Category</th>
                                <th>Images</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($products as $product)
                                <tr>
                                    <td>{{$product->id}}</td>
                                    <td>{{$product->Title}}</td>
                                    <td>{{$product->description}}</td>
                                    <td>{{$product->price}}</td>
                                    <td>{{$product->salePrice}}</td>
                                    <td>{{$product->inStock}}</td>
                                    <td>{{$product->count}}</td>
                                    <td>{{$product->color}}</td>
                                    <td>{{$product->categories['categoryTitle']}}</td>
                                    <td>@foreach($product->images as $image)
                                            <img class="img-thumbnail" src="{{ asset('uploads/products/'
                                        .$image->ImagePath)}}" alt="" height="50" width="50">
                                        @endforeach</td>

                                    <td>
                                        <a href="/admin/product/update/{{$product->id}}"
                                           type="button" class="btn btn-info">Update</a>
                                        <a href="/admin/product/delete/{{$product->id}}"
                                           type="button" class="btn btn-danger">Delete</a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
@include('admin.layouts.footer')