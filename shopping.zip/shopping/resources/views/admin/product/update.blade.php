@include('admin.layouts.head')

<div id="wrapper">
    <!-- Navigation -->
    @include('admin.layouts.navbar')

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Basic Form Elements
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <form method="POST"
                                      action="/admin/product/update"
                                      enctype="multipart/form-data">

                                    <div class="form-group">
                                        <label>Category</label>
                                        <select class="form-control" name="CategoryId">

                                            @foreach($categories as $category)
                                                <option value="{{$category->id}}">
                                                    {{$category->categoryTitle}}</option>

                                                @foreach($category->subCategory as $subCategory)
                                                    <option value="{{$subCategory->id}}">
                                                        {{$category->categoryTitle}}
                                                        ->
                                                        {{$subCategory->categoryTitle}}
                                                    </option>

                                                    @foreach($subCategory->subCategory as $subsubCategory)
                                                        <option value="{{$subsubCategory->id}}">
                                                            {{$category->categoryTitle}}
                                                            ->
                                                            {{$subCategory->categoryTitle}}
                                                            ->
                                                            {{$subsubCategory->categoryTitle}}
                                                        </option>
                                                    @endforeach
                                                @endforeach
                                            @endforeach

                                        </select>
                                    </div>
                                    @foreach($products as $product)
                                    <div class="form-group">
                                        <label>Product Title</label>
                                        <input class="form-control" name="Title"
                                               placeholder="Product Title"
                                                value="{{$product->Title}}">
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control"
                                         name="Description"
                                         rows="3">{{$product->description}}</textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Price</label>
                                        <input class="form-control" name="Price"
                                               placeholder="Price"
                                               value="{{$product->price}}">
                                    </div>
                                    <div class="form-group">
                                        <label>Sale Price</label>
                                        <input class="form-control" name="SalePrice"
                                               placeholder="Sale Price"
                                        value="{{$product->salePrice}}">
                                    </div>
                                    <div class="form-group">
                                        <label>Count</label>
                                        <input class="form-control" name="Count"
                                               placeholder="Count"
                                               value="{{$product->count}}">
                                    </div>

                                        <div class="form-group">
                                            <label>Is Stock</label>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox"
                                                           name="IsStock"
                                                           value="{{$product->isStock}}"
                                                    >Is Stock
                                                </label>
                                            </div>
                                        </div>
                                    <div class="form-group">
                                        <label>Color</label>
                                        <input class="form-control" name="Color"
                                               placeholder="Color"
                                               value="{{$product->color}}">
                                    </div>
                                    <div class="form-group">
                                        <label>Is Active</label>
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox"
                                                       value="{{$product->isActive}}"
                                                       name="IsActive"
                                                >Active
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                    @foreach($product->images as $image)
                                        <img class="img-thumbnail" src="{{ asset('product'
                                        .$image->ImagePath)}}" alt="" height="150" width="150">
                                    @endforeach
                                    </div>
                                    <div class="form-group">
                                        <label>Images</label>
                                        <input type="file" name="Images[]" multiple>
                                    </div>
                                    <input type="hidden" name="Id" value="{{ $product->id }}">
                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <button type="submit" class="btn btn-default">Save</button>
                                    @endforeach
                                </form>
                            </div>

                            <div class="col-lg-6">

                            </div>
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
    </div>
    <!-- /#wrapper -->
</div>
@include('admin.layouts.footer')