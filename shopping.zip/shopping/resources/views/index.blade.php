@include('layouts.head')

<!-- Document Wrapper
============================================= -->
<div class="wrapper-box">
    <!-- Header
    ============================================= -->
    <div id="header">
        <header class="header-row">
            <div class="container">
                <div class="table-container">
                    <!-- Top Bar
                      ============================================= -->
                    <nav class="htop col-md-9 pull-right flip inner" id="top"> <span class="drop-icon visible-sm visible-xs"><i class="fa fa-align-justify"></i></span>
                        <div id="top-links" class="nav pull-right flip">
                            <ul>
                                @if(Route::has('login'))
                                    @auth
                                    <li><a href="{{ url('/home') }}">Home</a></li>
                                    @else
                                    <li> <a href="{{ route('login') }}">Login</a></li>
                                    <li> <a href="{{ route('register') }}">Register</a></li>
                                    @endauth
                                @endif
                            </ul>
                        </div>
                        <div class="pull-right flip left-top">
                            <div class="links">
                                <ul>
                                    <li><a href="#" target="_self">Custom Links</a></li>
                                    <!--<li class="wrap_custom_block hidden-sm hidden-xs"><a>Custom Block<b></b></a>
                                        <div class="dropdown-menu custom_block">
                                            <ul>
                                                <li>
                                                    <table>
                                                        <tbody>
                                                        <tr>
                                                            <td><h3>Custom Block</h3></td>
                                                        </tr>
                                                        <tr>
                                                            <td><img src="image/banner/sb.jpg"></td>
                                                        </tr>
                                                        <tr>
                                                            <td><p>This is a CMS block edited from theme admin panel. You can insert any content (HTML, Text, Images) Here. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                                <p><a target="" href="#">Read More</a>
                                                                </p></td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>-->
                                    <li><a href="wishlist.html" id="wishlist-total">Wish List (0)</a></li>
                                </ul>
                            </div>
                            <!--<div id="language" class="btn-group">
                                <button class="btn-link dropdown-toggle" data-toggle="dropdown"> <span>
                                        <img src="image/flags/gb.png"
                                             alt="English" title="English">English
                                        <i class="fa fa-caret-down"></i></span></button>
                                <ul class="dropdown-menu">
                                    <li>
                                        <button class="btn btn-link btn-block language-select"
                                                type="button" name="GB"><img src="image/flags/gb.png"
                                                alt="English" title="English" /> English</button>
                                    </li>
                                    <li>
                                        <button class="btn btn-link btn-block language-select"
                                                type="button" name="GB"><img src="image/flags/ar.png"
                                                alt="Arabic" title="Arabic" /> Arabic</button>
                                    </li>
                                </ul>
                            </div>-->
                            <div id="currency" class="btn-group">
                                <button class="btn-link dropdown-toggle" data-toggle="dropdown"> <span> $ USD <i class="fa fa-caret-down"></i></span></button>
                                <ul class="dropdown-menu">
                                    <li>
                                        <button class="currency-select btn btn-link btn-block" type="button" name="EUR">€ Euro</button>
                                    </li>
                                    <li>
                                        <button class="currency-select btn btn-link btn-block" type="button" name="GBP">£ Pound Sterling</button>
                                    </li>
                                    <li>
                                        <button class="currency-select btn btn-link btn-block" type="button" name="USD">$ US Dollar</button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav><!-- Top Bar End -->

                    <!-- Logo
                    ============================================= -->
                    <div class="col-table-cel col-md-3 col-sm-4 col-xs-12 inner">
                        <div id="logo"><a href="/"><img class="img-responsive"
                                       src="{{ asset('img/logo.png')}}" title="Bigshop"
                                                        alt="Bigshop" /></a></div>
                    </div><!-- Logo End -->

                    <!-- Phone and Email
                    ============================================= -->
                    <div class="col-md-4 col-md-push-5 col-sm-8 col-xs-12 inner">
                        <div class="links_contact pull-right flip">
                            <ul>
                                <li class="mobile"><i class="fa fa-phone"></i>+91 98989898</li>
                                <li class="email"><a href="mailto:support@bigshop.com"><i class="fa fa-envelope"></i>support@bigshop.com</a></li>
                            </ul>
                        </div>
                    </div><!-- Phone and Email End-->

                    <div class="clearfix visible-sm-block visible-xs-block"></div>

                    <!-- Search Bar
                    ============================================= -->
                    <div class="col-md-5 col-md-pull-4 col-sm-8 col-xs-12 inner2">
                        <div id="search" class="input-group">
                            <input id="filter_name" type="text" name="search" value="" placeholder="Search" class="form-control input-lg" />
                            <button type="button" class="button-search"><i class="fa fa-search"></i></button>
                        </div>
                    </div><!-- Search Bar End-->

                    <!-- Mini Cart
                    ============================================= -->
                    @include('layouts.minicart')
                   <!-- Mini Cart End-->
                </div>
            </div>
        </header>

        <!-- Main Menu
        ============================================= -->
        <div class="container">
            @include('layouts.navbar')
        </div><!-- Main Menu End-->
    </div><!-- Header End-->

    <!-- Content
    ============================================= -->
    <div id="container">

        <div class="container">
            <div class="row">
                <!-- Left Part
                ============================================= -->
            @include('layouts.sidebar')
                <!-- Middle Part
                ============================================= -->
                <div id="content" class="col-sm-9">

                    <!-- Welcome Text
                    ============================================= -->
                    <p class="lead text-center">"The clean and modern look allows you to use the template for every kind of eCommerce online shop. Great Looks on Desktops, Tablets and Mobiles."</p><!-- Welcome Text End-->

                    <!-- Slideshow
                    ============================================= -->
                    <div class="slideshow single-slider owl-carousel">
                        <div class="item"> <a href="#"><img class="img-responsive" src="image/slider/banner-1.jpg" alt="banner 1" /></a> </div>
                        <div class="item"> <a href="#"><img class="img-responsive" src="image/slider/banner-2.jpg" alt="banner 2" /></a> </div>
                        <div class="item"> <a href="#"><img class="img-responsive" src="image/slider/banner-3.jpg" alt="banner 3" /></a> </div>
                        <div class="item"> <a href="#"><img class="img-responsive" src="image/slider/banner-4.jpg" alt="banner 4" /></a> </div>
                    </div><!-- Slideshow End-->

                    <!-- Product Tab
                    ============================================= -->
                    <div id="product-tab" class="product-tab">
                        <ul id="tabs" class="tabs clearfix">
                            <li><a href="#tab-featured">Featured</a></li>
                            <li><a href="#tab-latest">Latest</a></li>
                            <!--<li><a href="#tab-bestseller">Bestseller</a></li>
                            <li><a href="#tab-special">Special</a></li>-->
                        </ul>
                        <div id="tab-featured" class="tab_content">
                            <div class="row products-category product_tab_grid">
                                @foreach($products->take(12) as $product)
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="{{'/product/'.$product->id}}">
                                                @foreach($product->images->take(1) as $image)
                                                    <img src="{{'/uploads/products/'.$image->ImagePath}}"
                                                         alt="Apple Cinema 30&quot;"
                                                         title="Apple Cinema 30&quot;"
                                                         class="img-responsive" /></a></div>
                                                @endforeach
                                        <div class="caption">
                                            <h4><a href="{{'/product/'.$product->id}}">{{$product->Title}}</a></h4>
                                            <p class="price"> <span class="price-new">${{$product->salePrice}}</span>
                                                <span class="price-old">${{$product->price}}</span>
                                                <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary add-to-cart" type="button" data-id="{{$product->id}}"><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                        <div id="tab-latest" class="tab_content">
                            <div class="row products-category product_tab_grid">
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/samsung_tab_1-200x200.jpg" alt="Samsung Galaxy Tab 10.1" title="Samsung Galaxy Tab 10.1" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Samsung Galaxy Tab 10.1</a></h4>
                                            <p class="price"> <span class="price-new">$218.00</span> <span class="price-old">$241.99</span> <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!--<div id="tab-bestseller" class="tab_content">
                            <div class="row products-category product_tab_grid">
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/htc_touch_hd_1-200x200.jpg" alt="HTC Touch HD" title="HTC Touch HD" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">HTC Touch HD</a></h4>
                                            <p class="price"> $122.00 </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div id="tab-special" class="tab_content">
                            <div class="row products-category product_tab_grid">

                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/samsung_tab_1-200x200.jpg" alt="Samsung Galaxy Tab 10.1" title="Samsung Galaxy Tab 10.1" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Samsung Galaxy Tab 10.1</a></h4>
                                            <p class="price"> <span class="price-new">$218.00</span> <span class="price-old">$241.99</span> <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div><!-- Product End-->






                </div><!--Middle Part End-->

            </div>
        </div>
    </div><!--Content End-->

    <!-- Feature Box
    ============================================= -->
    <div class="container">
        <div class="custom-feature-box row">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="feature-box fbox_1">
                    <div class="title">Free & Easy Return</div>
                    <p>Free return in 7 Days after purchasing</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="feature-box fbox_2">
                    <div class="title">Free Shipping</div>
                    <p>Free shipping on order over $1000</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="feature-box fbox_3">
                    <div class="title">Gift Cards</div>
                    <p>Give the special perfect gift</p>
                </div>
            </div>
        </div>
    </div><!-- Feature Box End-->
</div>
    @include('layouts.footer')