<nav id="menu" class="navbar">
    <div class="navbar-header"><span class="visible-xs visible-sm"> Menu <i
                    class="fa fa-align-justify pull-right flip"></i></span></div>
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav">
            <li><a class="home_link" title="Home" href="/">
                 <i class="fa fa-home"></i> </a></li>
            @foreach($categories as $category)
                <li class="categories_defu dropdown sub">
                    <a class="dropdown-toggle" href="{{$category->categoryUrl}}">{{$category->categoryTitle}}</a>
                    <span class="submore"></span>
                    @foreach($category->subCategory as $subCategory)
                        <div class="dropdown-menu" style="display: none;">
                            <ul>
                                <li><a href="{{$subCategory->categoryUrl}}">
                                        {{$subCategory->categoryTitle}}
                                        @if($subCategory->subCategory->count() != 0)
                                        <span class="fa fa-caret-right"></span>
                                        @endif</a>
                                    <span class="submore"></span>
                                    @foreach($subCategory->subCategory as $subsubCategory)
                                        <div class="dropdown-menu" style="display: none;">
                                            <ul>
                                                <li><a href="{{$subsubCategory->categoryUrl}}">
                                                        {{$subsubCategory->categoryTitle}}
                                                        @if($subsubCategory->subCategory->count() != 0)
                                                            <span class="fa fa-caret-right"></span>
                                                        @endif</a>
                                                </li>
                                            </ul>
                                        </div>
                                    @endforeach
                                </li>
                            </ul>
                        </div>
                    @endforeach
                </li>
            @endforeach
        </ul>
    </div>
</nav>