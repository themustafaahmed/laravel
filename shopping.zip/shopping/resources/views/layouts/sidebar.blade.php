<aside id="column-left" class="col-sm-3 hidden-xs">

    <!-- Categories Accordion
    ============================================= -->
    <h3 class="subtitle"><span>Categories</span></h3>
    <div class="box-category">
        <ul id="cat_accordion">
            @foreach($categories as $category)
            <li><a href="{{'/category/'.$category->categoryUrl}}">
                    {{$category->categoryTitle}}</a>
                @if($category->subCategory->count() != null)
                <span class="down"></span>
                @endif
                <ul>
                @foreach($category->subCategory as $subCategory)
                    <li><a href="{{'/category/'.$subCategory->categoryUrl}}">
                            {{$subCategory->categoryTitle}} </a>
                        @if($subCategory->subCategory->count() != null)
                        <span class="down"></span>
                        @endif
                        <ul>
                        @foreach($subCategory->subCategory as $subSubCategory)
                            <li><a href="{{'/category/'.$subSubCategory->categoryUrl}}">
                                    {{$subSubCategory->categoryTitle}}</a></li>
                        @endforeach
                        </ul>
                    </li>
                @endforeach
                </ul>
            </li>
            @endforeach
        </ul>
    </div><!-- Categories Accordion End-->

    <!-- Bestsellers
    ============================================= -->
    <h3 class="subtitle"><span>Bestsellers</span></h3>
    <div class="side-item">
        <div class="product-thumb clearfix">
            <div class="image"><a href="product.html">
                    <img src="image/product/htc_touch_hd_1-60x60.jpg" alt="HTC Touch HD" title="HTC Touch HD" class="img-responsive" /></a></div>
            <div class="caption">
                <h4><a href="product.html">HTC Touch HD</a></h4>
                <p class="price"> $122.00 </p>
                <div class="rating"> <span class="fa fa-stack">
                        <i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
            </div>
        </div>

    </div><!-- Bestsellers End-->

    <!-- Banners
    ============================================= -->
    <div class="bigshop-banner">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 moderns">
                <a href="#"><img src="" alt="sample banner"
                                 title="sample banner" /></a></div>
        </div>
    </div><!-- Banners End-->

    <!-- Specials
    ============================================= -->
    <h3 class="subtitle"><span>Specials</span></h3>
    <div class="side-item">
        <div class="product-thumb clearfix">
            <div class="image"><a href="product.html">
                    <img src="image/product/apple_cinema_30-60x60.jpg" alt="Apple Cinema 30&quot;" title="Apple Cinema 30&quot;" class="img-responsive" /></a></div>
            <div class="caption">
                <h4><a href="product.html">Apple Cinema 30&quot;</a></h4>
                <p class="price"> <span class="price-new">$110.00</span> <span class="price-old">$122.00</span> <span class="saving">-10%</span> </p>
            </div>
        </div>

    </div><!-- Specials End-->

    <!-- Custom Content
    ============================================= -->
    <div class="list-group">
        <h3 class="subtitle"><span>Custom Content</span></h3>
        <p>This is a CMS block. You can insert any content (HTML, Text, Images) Here. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
    </div>
</aside><!-- Custom Content End-->
