<!doctype html>
<html lang="{{ app()->getLocale() }}">
<body>
    @foreach($products as $product)
     {{$product->Title}}
    @endforeach
</body>
</html>