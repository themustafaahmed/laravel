@include('layouts.head')

<!-- Document Wrapper
============================================= -->
<div class="wrapper-box">
    <!-- Header
    ============================================= -->
    <div id="header">
        <header class="header-row">
            <div class="container">
                <div class="table-container">
                    <!-- Top Bar
                      ============================================= -->
                    <nav class="htop col-md-9 pull-right flip inner" id="top"> <span class="drop-icon visible-sm visible-xs"><i class="fa fa-align-justify"></i></span>
                        <div id="top-links" class="nav pull-right flip">
                            <ul>
                                @if(Route::has('login'))
                                    @auth
                                    <li><a href="{{ url('/home') }}">Home</a></li>
                                    @else
                                    <li> <a href="{{ route('login') }}">Login</a></li>
                                    <li> <a href="{{ route('register') }}">Register</a></li>
                                    @endauth
                                @endif
                            </ul>
                        </div>
                        <div class="pull-right flip left-top">
                            <div class="links">
                                <ul>
                                    <li><a href="#" target="_self">Custom Links</a></li>
                                    <li class="wrap_custom_block hidden-sm hidden-xs"><a>Custom Block<b></b></a>
                                        <div class="dropdown-menu custom_block">
                                            <ul>
                                                <li>
                                                    <table>
                                                        <tbody>
                                                        <tr>
                                                            <td><h3>Custom Block</h3></td>
                                                        </tr>
                                                        <tr>
                                                            <td><img src="image/banner/sb.jpg"></td>
                                                        </tr>
                                                        <tr>
                                                            <td><p>This is a CMS block edited from theme admin panel. You can insert any content (HTML, Text, Images) Here. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                                <p><a target="" href="#">Read More</a>
                                                                </p></td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li><a href="wishlist.html" id="wishlist-total">Wish List (0)</a></li>
                                </ul>
                            </div>
                            <div id="language" class="btn-group">
                                <button class="btn-link dropdown-toggle" data-toggle="dropdown"> <span> <img src="image/flags/gb.png" alt="English" title="English">English <i class="fa fa-caret-down"></i></span></button>
                                <ul class="dropdown-menu">
                                    <li>
                                        <button class="btn btn-link btn-block language-select" type="button" name="GB"><img src="image/flags/gb.png" alt="English" title="English" /> English</button>
                                    </li>
                                    <li>
                                        <button class="btn btn-link btn-block language-select" type="button" name="GB"><img src="image/flags/ar.png" alt="Arabic" title="Arabic" /> Arabic</button>
                                    </li>
                                </ul>
                            </div>
                            <div id="currency" class="btn-group">
                                <button class="btn-link dropdown-toggle" data-toggle="dropdown"> <span> $ USD <i class="fa fa-caret-down"></i></span></button>
                                <ul class="dropdown-menu">
                                    <li>
                                        <button class="currency-select btn btn-link btn-block" type="button" name="EUR">€ Euro</button>
                                    </li>
                                    <li>
                                        <button class="currency-select btn btn-link btn-block" type="button" name="GBP">£ Pound Sterling</button>
                                    </li>
                                    <li>
                                        <button class="currency-select btn btn-link btn-block" type="button" name="USD">$ US Dollar</button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav><!-- Top Bar End -->

                    <!-- Logo
                    ============================================= -->
                    <div class="col-table-cel col-md-3 col-sm-4 col-xs-12 inner">
                        <div id="logo"><a href="index.html"><img class="img-responsive" src="image/logo.png" title="Bigshop" alt="Bigshop" /></a></div>
                    </div><!-- Logo End -->

                    <!-- Phone and Email
                    ============================================= -->
                    <div class="col-md-4 col-md-push-5 col-sm-8 col-xs-12 inner">
                        <div class="links_contact pull-right flip">
                            <ul>
                                <li class="mobile"><i class="fa fa-phone"></i>+91 98989898</li>
                                <li class="email"><a href="mailto:support@bigshop.com"><i class="fa fa-envelope"></i>support@bigshop.com</a></li>
                            </ul>
                        </div>
                    </div><!-- Phone and Email End-->

                    <div class="clearfix visible-sm-block visible-xs-block"></div>

                    <!-- Search Bar
                    ============================================= -->
                    <div class="col-md-5 col-md-pull-4 col-sm-8 col-xs-12 inner2">
                        <div id="search" class="input-group">
                            <input id="filter_name" type="text" name="search" value="" placeholder="Search" class="form-control input-lg" />
                            <button type="button" class="button-search"><i class="fa fa-search"></i></button>
                        </div>
                    </div><!-- Search Bar End-->

                    <!-- Mini Cart
                    ============================================= -->
                    <div class="col-md-9 pull-right col-sm-4 col-xs-12 inner">
                        <div id="cart">
                            <button type="button" data-toggle="dropdown" data-loading-text="Loading..." class="heading dropdown-toggle">
                                <span class="cart-icon pull-left flip"></span>
                                <span id="cart-total">2 item(s) - $1,132.00</span> <i class="fa fa-caret-down"></i></button>
                            <ul class="dropdown-menu">
                                <li>
                                    <table class="table">
                                        <tbody>
                                        <tr>
                                            <td class="text-center"><a href="product.html"><img class="img-thumbnail" title="Xitefun Causal Wear Fancy Shoes" alt="Xitefun Causal Wear Fancy Shoes" src="image/product/sony_vaio_1-60x60.jpg"></a></td>
                                            <td class="text-left"><a href="product.html">Xitefun Causal Wear Fancy Shoes</a></td>
                                            <td class="text-right">x 1</td>
                                            <td class="text-right">$902.00</td>
                                            <td class="text-center"><button class="btn btn-danger btn-xs remove" title="Remove" onClick="" type="button"><i class="fa fa-times"></i></button></td>
                                        </tr>
                                        <tr>
                                            <td class="text-center"><a href="product.html"><img class="img-thumbnail" title="Aspire Ultrabook Laptop" alt="Aspire Ultrabook Laptop" src="image/product/samsung_tab_1-60x60.jpg"></a></td>
                                            <td class="text-left"><a href="product.html">Aspire Ultrabook Laptop</a></td>
                                            <td class="text-right">x 1</td>
                                            <td class="text-right">$230.00</td>
                                            <td class="text-center"><button class="btn btn-danger btn-xs remove" title="Remove" onClick="" type="button"><i class="fa fa-times"></i></button></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </li>
                                <li>
                                    <div>
                                        <table class="table table-bordered">
                                            <tbody>
                                            <tr>
                                                <td class="text-right"><strong>Sub-Total</strong></td>
                                                <td class="text-right">$940.00</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>Eco Tax (-2.00)</strong></td>
                                                <td class="text-right">$4.00</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>VAT (20%)</strong></td>
                                                <td class="text-right">$188.00</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>Total</strong></td>
                                                <td class="text-right">$1,132.00</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                        <p class="checkout"><a href="cart.html" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> View Cart</a>&nbsp;&nbsp;&nbsp;<a href="checkout.html" class="btn btn-primary"><i class="fa fa-share"></i> Checkout</a></p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div><!-- Mini Cart End-->
                </div>
            </div>
        </header>

        <!-- Main Menu
        ============================================= -->
        <div class="container">
            <nav id="menu" class="navbar">
                <div class="navbar-header"> <span class="visible-xs visible-sm"> Menu <i class="fa fa-align-justify pull-right flip"></i></span></div>
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav">
                        <li><a class="home_link" title="Home" href="index.html"> <i class="fa fa-home"></i> </a></li>
                        <li class="categories_defu dropdown"><a class="dropdown-toggle" href="category.html">Desktops</a>
                            <div class="dropdown-menu">
                                <ul>
                                    <li> <a href="category.html">PC</a> </li>
                                    <li> <a href="category.html">Mac</a> </li>
                                </ul>
                            </div>
                        </li>
                        <li class="categories_defu dropdown"><a class="dropdown-toggle" href="category.html">Laptops &amp; Notebooks</a>
                            <div class="dropdown-menu">
                                <ul>
                                    <li> <a href="category.html">Macs</a> </li>
                                    <li> <a href="category.html">Windows</a> </li>
                                </ul>
                            </div>
                        </li>
                        <li class="categories_defu dropdown"><a class="dropdown-toggle" href="category.html">Components</a>
                            <div class="dropdown-menu">
                                <ul>
                                    <li> <a href="category.html">Mice and Trackballs</a> </li>
                                    <li> <a href="category.html">Monitors <span class='fa fa-caret-right'></span></a>
                                        <div class="dropdown-menu">
                                            <ul>
                                                <li> <a href="category.html">SubCategory 1 </a> </li>
                                                <li> <a href="category.html">SubCategory 2 <span class='fa fa-caret-right'></span></a>
                                                    <div class="dropdown-menu">
                                                        <ul>
                                                            <li> <a href="category.html">New SubCategory 1 </a> </li>
                                                            <li> <a href="category.html">New SubCategory 2 </a> </li>
                                                            <li> <a href="category.html">New SubCategory 3 </a> </li>
                                                            <li> <a href="category.html">New SubCategory 4 </a> </li>
                                                            <li> <a href="category.html">New SubCategory 5 </a> </li>
                                                        </ul>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li> <a href="category.html">Printers</a> </li>
                                    <li> <a href="category.html">Scanners</a> </li>
                                    <li> <a href="category.html">Web Cameras</a> </li>
                                </ul>
                            </div>
                        </li>
                        <li class="categories_defu dropdown"><a class="dropdown-toggle" href="category.html">Cameras</a> </li>
                        <li class="categories_defu dropdown"><a class="dropdown-toggle" href="category.html">MP3 Players</a>
                            <div class="dropdown-menu">
                                <ul>
                                    <li> <a href="category.html">SubCategory 11</a> </li>
                                    <li> <a href="category.html">SubCategory 12</a> </li>
                                    <li> <a href="category.html">SubCategory 15</a> </li>
                                    <li> <a href="category.html">SubCategory 16</a> </li>
                                    <li> <a href="category.html">SubCategory 17</a> </li>
                                </ul>
                                <ul>
                                    <li> <a href="category.html">SubCategory 18</a> </li>
                                    <li> <a href="category.html">SubCategory 19</a> </li>
                                    <li> <a href="category.html">SubCategory 20 <span class='fa fa-caret-right'></span></a>
                                        <div class="dropdown-menu">
                                            <ul>
                                                <li> <a href="category.html"  >SubCategory 25 </a> </li>
                                                <li> <a href="category.html"  >SubCategory 26 </a> </li>
                                                <li> <a href="category.html"  >SubCategory 27 </a> </li>
                                                <li> <a href="category.html"  >SubCategory 28 </a> </li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li> <a href="category.html">SubCategory 21</a> </li>
                                    <li> <a href="category.html">SubCategory 22</a> </li>
                                </ul>
                                <ul>
                                    <li> <a href="category.html">SubCategory 23</a> </li>
                                    <li> <a href="category.html">SubCategory 24</a> </li>
                                    <li> <a href="category.html">SubCategory 4</a> </li>
                                    <li> <a href="category.html">SubCategory 5</a> </li>
                                    <li> <a href="category.html">SubCategory 6</a> </li>
                                </ul>
                                <ul>
                                    <li> <a href="category.html">SubCategory 7</a> </li>
                                    <li> <a href="category.html">SubCategory 8</a> </li>
                                    <li> <a href="category.html">SubCategory 9</a> </li>
                                </ul>
                            </div>
                        </li>
                        <li class="menu_brands name dropdown"> <a href="category.html">Brands</a>
                            <div class="dropdown-menu">
                                <ul>
                                    <li><a href="#">Apple</a></li>
                                    <li><a href="#">Canon</a></li>
                                    <li><a href="#">Hewlett-Packard</a></li>
                                    <li><a href="#">HTC</a></li>
                                    <li><a href="#">Palm</a></li>
                                    <li><a href="#">Sony</a></li>
                                </ul>
                            </div>
                        <li class="dropdown wrap_custom_block hidden-sm hidden-xs"><a>Custom Block</a>
                            <div class="dropdown-menu custom_block">
                                <ul>
                                    <li>
                                        <table style="width:275px; height: 250px;">
                                            <tbody>
                                            <tr>
                                                <td><h3>Custom Block</h3></td>
                                            </tr>
                                            <tr>
                                                <td><img src="image/banner/sb2.jpg"></td>
                                            </tr>
                                            <tr>
                                                <td><p>This is a CMS block edited from theme admin panel. You can insert any content (HTML, Text, Images) Here. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                                    <p><br>
                                                    </p>
                                                    <p><a class="btn btn-primary" href="#">Read More</a><br>
                                                    </p></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="dropdown"><a href="blog.html">Blog</a>
                            <div class="dropdown-menu">
                                <ul>
                                    <li><a href="blog.html">Blog</a></li>
                                    <li><a href="blog-grid.html">Blog Grid</a></li>
                                    <li><a href="blog-detail.html">Single Post</a></li>
                                </ul>
                            </div>
                        </li>
                        <li class="dropdown"><a>Pages</a>
                            <div class="dropdown-menu">
                                <ul>
                                    <li><a href="category.html">Category (Grid/List)</a></li>
                                    <li><a href="product.html">Product Page</a></li>
                                    <li><a href="cart.html">Shopping Cart</a></li>
                                    <li><a href="checkout.html">Checkout</a></li>
                                    <li><a href="compare.html">Product Compare</a></li>
                                    <li><a href="wishlist.html">Wishlist</a></li>
                                    <li><a href="search.html">Search</a></li>
                                    <li><a href="manufacturer.html">Brands</a></li>
                                </ul>
                                <ul>
                                    <li><a href="about-us.html">About Us</a></li>
                                    <li><a href="elements.html">Elements</a></li>
                                    <li><a href="elements-forms.html">Forms</a></li>
                                    <li><a href="careers.html">Careers</a></li>
                                    <li><a href="faq.html">Faq</a></li>
                                    <li><a href="404.html">404</a></li>
                                    <li><a href="sitemap.html">Sitemap</a></li>
                                    <li><a href="contact-us.html">Contact Us</a></li>
                                    <li><a href="email-template" target="_blank">Email Template Page</a></li>
                                </ul>
                                <ul>
                                    <li><a href="login.html">Login</a></li>
                                    <li><a href="register.html">Register</a></li>
                                    <li><a href="my-account.html">My Account</a></li>
                                    <li><a href="order-history.html">Order History</a></li>
                                    <li><a href="order-information.html">Order Information</a></li>
                                    <li><a href="return.html">Return</a></li>
                                    <li><a href="gift-voucher.html">Gift Voucher</a></li>
                                </ul>
                            </div>
                        </li>
                        <li class="contact-link"><a href="contact-us.html">Contact Us</a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- Main Menu End-->
    </div><!-- Header End-->

    <!-- Content
    ============================================= -->
    <div id="container">

        <div class="container">
            <div class="row">
                <!-- Left Part
                ============================================= -->
                <aside id="column-left" class="col-sm-3 hidden-xs">

                    <!-- Categories Accordion
                    ============================================= -->
                    <h3 class="subtitle"><span>Categories</span></h3>
                    <div class="box-category">
                        <ul id="cat_accordion">
                            <li><a href="category.html">Desktops</a> <span class="down"></span>
                                <ul>
                                    <li><a href="category.html">PC</a></li>
                                    <li><a href="category.html">Mac</a></li>
                                </ul>
                            </li>
                            <li><a href="category.html">Laptops &amp; Notebooks</a> <span class="down"></span>
                                <ul>
                                    <li><a href="category.html">Macs</a></li>
                                    <li><a href="category.html">Windows</a></li>
                                </ul>
                            </li>
                            <li><a href="category.html">Components</a> <span class="down"></span>
                                <ul>
                                    <li><a href="category.html">Mice and Trackballs</a></li>
                                    <li><a href="category.html">Monitors</a> <span class="down"></span>
                                        <ul>
                                            <li><a href="category.html">SubCategory 1</a></li>
                                            <li><a href="category.html">SubCategory 2</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="category.html">Printers</a></li>
                                    <li><a href="category.html">Scanners</a></li>
                                    <li><a href="category.html">Web Cameras</a></li>
                                </ul>
                            </li>
                            <li><a href="category.html">Phones &amp; PDAs</a></li>
                            <li><a href="category.html">Cameras</a></li>
                            <li><a href="category.html">MP3 Players</a> <span class="down"></span>
                                <ul>
                                    <li><a href="category.html">SubCategory 11</a></li>
                                    <li><a href="category.html">SubCategory 12</a></li>
                                    <li><a href="category.html">SubCategory 15</a></li>
                                    <li><a href="category.html">SubCategory 16</a></li>
                                    <li><a href="category.html">SubCategory 17</a></li>
                                    <li><a href="category.html">SubCategory 18</a></li>
                                    <li><a href="category.html">SubCategory 19</a></li>
                                    <li><a href="category.html">SubCategory 20</a> <span class="down"></span>
                                        <ul>
                                            <li class="custom_id58"><a href="category.html">SubCategory 25</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="category.html">SubCategory 21</a></li>
                                    <li><a href="category.html">SubCategory 22</a></li>
                                    <li><a href="category.html">SubCategory 23</a></li>
                                    <li><a href="category.html">SubCategory 24</a></li>
                                    <li><a href="category.html">SubCategory 4</a></li>
                                    <li><a href="category.html">SubCategory 5</a></li>
                                    <li><a href="category.html">SubCategory 6</a></li>
                                    <li><a href="category.html">SubCategory 7</a></li>
                                    <li><a href="category.html">SubCategory 8</a></li>
                                    <li><a href="category.html">SubCategory 9</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div><!-- Categories Accordion End-->

                    <!-- Bestsellers
                    ============================================= -->
                    <h3 class="subtitle"><span>Bestsellers</span></h3>
                    <div class="side-item">
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/htc_touch_hd_1-60x60.jpg" alt="HTC Touch HD" title="HTC Touch HD" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">HTC Touch HD</a></h4>
                                <p class="price"> $122.00 </p>
                                <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                            </div>
                        </div>
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/apple_cinema_30-60x60.jpg" alt="Apple Cinema 30&quot;" title="Apple Cinema 30&quot;" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">Apple Cinema 30&quot;</a></h4>
                                <p class="price"> <span class="price-new">$110.00</span> <span class="price-old">$122.00</span> <span class="saving">-10%</span> </p>
                            </div>
                        </div>
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/iphone_1-60x60.jpg" alt="iPhone" title="iPhone" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">iPhone</a></h4>
                                <p class="price"> $123.20 </p>
                            </div>
                        </div>
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/hp_1-60x60.jpg" alt="HP LP3065" title="HP LP3065" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">HP LP3065</a></h4>
                                <p class="price"> $122.00 </p>
                            </div>
                        </div>
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/imac_1-60x60.jpg" alt="iMac" title="iMac" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">iMac</a></h4>
                                <p class="price"> <span class="price-new">$92.00</span> <span class="price-old">$122.00</span> <span class="saving">-25%</span> </p>
                            </div>
                        </div>
                    </div><!-- Bestsellers End-->

                    <!-- Banners
                    ============================================= -->
                    <div class="bigshop-banner">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 moderns"><a href="#"><img src="image/banner/sb.jpg" alt="sample banner" title="sample banner" /></a></div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 moderns"><a href="#"><img src="image/banner/sb2.jpg" alt="sb" title="sb" /></a></div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 moderns"><a href="#"><img src="image/banner/sb3.jpg" alt="sb banner" title="sb banner" /></a></div>
                        </div>
                    </div><!-- Banners End-->

                    <!-- Specials
                    ============================================= -->
                    <h3 class="subtitle"><span>Specials</span></h3>
                    <div class="side-item">
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/apple_cinema_30-60x60.jpg" alt="Apple Cinema 30&quot;" title="Apple Cinema 30&quot;" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">Apple Cinema 30&quot;</a></h4>
                                <p class="price"> <span class="price-new">$110.00</span> <span class="price-old">$122.00</span> <span class="saving">-10%</span> </p>
                            </div>
                        </div>
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/canon_eos_5d_1-60x60.jpg" alt="Canon EOS 5D" title="Canon EOS 5D" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">Canon EOS 5D</a></h4>
                                <p class="price"> <span class="price-new">$98.00</span> <span class="price-old">$122.00</span> <span class="saving">-20%</span> </p>
                                <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                            </div>
                        </div>
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/imac_1-60x60.jpg" alt="iMac" title="iMac" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">iMac</a></h4>
                                <p class="price"> <span class="price-new">$92.00</span> <span class="price-old">$122.00</span> <span class="saving">-25%</span> </p>
                            </div>
                        </div>
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/macbook_air_1-60x60.jpg" alt="MacBook Air" title="MacBook Air" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">MacBook Air</a></h4>
                                <p class="price"> <span class="price-new">$782.00</span> <span class="price-old">$1,202.00</span> <span class="saving">-35%</span> </p>
                            </div>
                        </div>
                        <div class="product-thumb clearfix">
                            <div class="image"><a href="product.html"><img src="image/product/samsung_tab_1-60x60.jpg" alt="Samsung Galaxy Tab 10.1" title="Samsung Galaxy Tab 10.1" class="img-responsive" /></a></div>
                            <div class="caption">
                                <h4><a href="product.html">Samsung Galaxy Tab 10.1</a></h4>
                                <p class="price"> <span class="price-new">$218.00</span> <span class="price-old">$241.99</span> <span class="saving">-10%</span> </p>
                            </div>
                        </div>
                    </div><!-- Specials End-->

                    <!-- Custom Content
                    ============================================= -->
                    <div class="list-group">
                        <h3 class="subtitle"><span>Custom Content</span></h3>
                        <p>This is a CMS block. You can insert any content (HTML, Text, Images) Here. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                </aside><!-- Custom Content End-->

                <!-- Middle Part
                ============================================= -->
                <div id="content" class="col-sm-9">

                    <!-- Welcome Text
                    ============================================= -->
                    <p class="lead text-center">"The clean and modern look allows you to use the template for every kind of eCommerce online shop. Great Looks on Desktops, Tablets and Mobiles."</p><!-- Welcome Text End-->

                    <!-- Slideshow
                    ============================================= -->
                    <div class="slideshow single-slider owl-carousel">
                        <div class="item"> <a href="#"><img class="img-responsive" src="image/slider/banner-1.jpg" alt="banner 1" /></a> </div>
                        <div class="item"> <a href="#"><img class="img-responsive" src="image/slider/banner-2.jpg" alt="banner 2" /></a> </div>
                        <div class="item"> <a href="#"><img class="img-responsive" src="image/slider/banner-3.jpg" alt="banner 3" /></a> </div>
                        <div class="item"> <a href="#"><img class="img-responsive" src="image/slider/banner-4.jpg" alt="banner 4" /></a> </div>
                    </div><!-- Slideshow End-->

                    <!-- Product Tab
                    ============================================= -->
                    <div id="product-tab" class="product-tab">
                        <ul id="tabs" class="tabs clearfix">
                            <li><a href="#tab-featured">Featured</a></li>
                            <li><a href="#tab-latest">Latest</a></li>
                            <li><a href="#tab-bestseller">Bestseller</a></li>
                            <li><a href="#tab-special">Special</a></li>
                        </ul>
                        <div id="tab-featured" class="tab_content">
                            <div class="row products-category product_tab_grid">
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/apple_cinema_30-200x200.jpg" alt="Apple Cinema 30&quot;" title="Apple Cinema 30&quot;" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Apple Cinema 30&quot;</a></h4>
                                            <p class="price"> <span class="price-new">$110.00</span> <span class="price-old">$122.00</span> <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/htc_touch_hd_1-200x200.jpg" alt="HTC Touch HD" title="HTC Touch HD" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">HTC Touch HD</a></h4>
                                            <p class="price"> $122.00 </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/imac_1-200x200.jpg" alt="iMac" title="iMac" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iMac</a></h4>
                                            <p class="price"> <span class="price-new">$92.00</span> <span class="price-old">$122.00</span> <span class="saving">-25%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/hp_1-200x200.jpg" alt="HP LP3065" title="HP LP3065" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">HP LP3065</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/samsung_tab_1-200x200.jpg" alt="Samsung Galaxy Tab 10.1" title="Samsung Galaxy Tab 10.1" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Samsung Galaxy Tab 10.1</a></h4>
                                            <p class="price"> <span class="price-new">$218.00</span> <span class="price-old">$241.99</span> <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/samsung_syncmaster_941bw-200x200.jpg" alt="Samsung SyncMaster 941BW" title="Samsung SyncMaster 941BW" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Samsung SyncMaster 941BW</a></h4>
                                            <p class="price"> $242.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/nikon_d300_1-200x200.jpg" alt="Nikon D300" title="Nikon D300" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Nikon D300</a></h4>
                                            <p class="price"> $98.00 </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/ipod_touch_1-200x200.jpg" alt="iPod Touch" title="iPod Touch" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iPod Touch</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/ipod_shuffle_1-200x200.jpg" alt="iPod Shuffle" title="iPod Shuffle" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iPod Shuffle</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/canon_eos_5d_1-200x200.jpg" alt="Canon EOS 5D" title="Canon EOS 5D" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Canon EOS 5D</a></h4>
                                            <p class="price"> <span class="price-new">$98.00</span> <span class="price-old">$122.00</span> <span class="saving">-20%</span> </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/macbook_air_1-200x200.jpg" alt="MacBook Air" title="MacBook Air" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">MacBook Air</a></h4>
                                            <p class="price"> <span class="price-new">$782.00</span> <span class="price-old">$1,202.00</span> <span class="saving">-35%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab-latest" class="tab_content">
                            <div class="row products-category product_tab_grid">
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/samsung_tab_1-200x200.jpg" alt="Samsung Galaxy Tab 10.1" title="Samsung Galaxy Tab 10.1" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Samsung Galaxy Tab 10.1</a></h4>
                                            <p class="price"> <span class="price-new">$218.00</span> <span class="price-old">$241.99</span> <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/ipod_classic_1-200x200.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iPod Classic</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/hp_1-200x200.jpg" alt="HP LP3065" title="HP LP3065" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">HP LP3065</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/sony_vaio_1-200x200.jpg" alt="Sony VAIO" title="Sony VAIO" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Sony VAIO</a></h4>
                                            <p class="price"> $1,202.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/macbook_pro_1-200x200.jpg" alt="MacBook Pro" title="MacBook Pro" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">MacBook Pro</a></h4>
                                            <p class="price"> $2,000.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/macbook_air_1-200x200.jpg" alt="MacBook Air" title="MacBook Air" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">MacBook Air</a></h4>
                                            <p class="price"> <span class="price-new">$782.00</span> <span class="price-old">$1,202.00</span> <span class="saving">-35%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/macbook_1-200x200.jpg" alt="MacBook" title="MacBook" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">MacBook</a></h4>
                                            <p class="price"> $602.00 </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/apple_cinema_30-200x200.jpg" alt="Apple Cinema 30&quot;" title="Apple Cinema 30&quot;" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Apple Cinema 30&quot;</a></h4>
                                            <p class="price"> <span class="price-new">$110.00</span> <span class="price-old">$122.00</span> <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/imac_1-200x200.jpg" alt="iMac" title="iMac" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iMac</a></h4>
                                            <p class="price"> <span class="price-new">$92.00</span> <span class="price-old">$122.00</span> <span class="saving">-25%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/iphone_1-200x200.jpg" alt="iPhone" title="iPhone" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iPhone</a></h4>
                                            <p class="price"> $123.20 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/ipod_nano_1-200x200.jpg" alt="iPod Nano" title="iPod Nano" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iPod Nano</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/ipod_shuffle_1-200x200.jpg" alt="iPod Shuffle" title="iPod Shuffle" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iPod Shuffle</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/samsung_syncmaster_941bw-200x200.jpg" alt="Samsung SyncMaster 941BW" title="Samsung SyncMaster 941BW" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Samsung SyncMaster 941BW</a></h4>
                                            <p class="price"> $242.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/ipod_touch_1-200x200.jpg" alt="iPod Touch" title="iPod Touch" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iPod Touch</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/nikon_d300_1-200x200.jpg" alt="Nikon D300" title="Nikon D300" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Nikon D300</a></h4>
                                            <p class="price"> $98.00 </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab-bestseller" class="tab_content">
                            <div class="row products-category product_tab_grid">
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/htc_touch_hd_1-200x200.jpg" alt="HTC Touch HD" title="HTC Touch HD" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">HTC Touch HD</a></h4>
                                            <p class="price"> $122.00 </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/apple_cinema_30-200x200.jpg" alt="Apple Cinema 30&quot;" title="Apple Cinema 30&quot;" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Apple Cinema 30&quot;</a></h4>
                                            <p class="price"> <span class="price-new">$110.00</span> <span class="price-old">$122.00</span> <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/iphone_1-200x200.jpg" alt="iPhone" title="iPhone" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iPhone</a></h4>
                                            <p class="price"> $123.20 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/hp_1-200x200.jpg" alt="HP LP3065" title="HP LP3065" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">HP LP3065</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/imac_1-200x200.jpg" alt="iMac" title="iMac" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iMac</a></h4>
                                            <p class="price"> <span class="price-new">$92.00</span> <span class="price-old">$122.00</span> <span class="saving">-25%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/macbook_air_1-200x200.jpg" alt="MacBook Air" title="MacBook Air" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">MacBook Air</a></h4>
                                            <p class="price"> <span class="price-new">$782.00</span> <span class="price-old">$1,202.00</span> <span class="saving">-35%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/samsung_syncmaster_941bw-200x200.jpg" alt="Samsung SyncMaster 941BW" title="Samsung SyncMaster 941BW" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Samsung SyncMaster 941BW</a></h4>
                                            <p class="price"> $242.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/macbook_1-200x200.jpg" alt="MacBook" title="MacBook" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">MacBook</a></h4>
                                            <p class="price"> $602.00 </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/canon_eos_5d_1-200x200.jpg" alt="Canon EOS 5D" title="Canon EOS 5D" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Canon EOS 5D</a></h4>
                                            <p class="price"> <span class="price-new">$98.00</span> <span class="price-old">$122.00</span> <span class="saving">-20%</span> </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/nikon_d300_1-200x200.jpg" alt="Nikon D300" title="Nikon D300" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Nikon D300</a></h4>
                                            <p class="price"> $98.00 </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/sony_vaio_1-200x200.jpg" alt="Sony VAIO" title="Sony VAIO" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Sony VAIO</a></h4>
                                            <p class="price"> $1,202.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/macbook_pro_1-200x200.jpg" alt="MacBook Pro" title="MacBook Pro" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">MacBook Pro</a></h4>
                                            <p class="price"> $2,000.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/ipod_touch_1-200x200.jpg" alt="iPod Touch" title="iPod Touch" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iPod Touch</a></h4>
                                            <p class="price"> $122.00 </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab-special" class="tab_content">
                            <div class="row products-category product_tab_grid">
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/apple_cinema_30-200x200.jpg" alt="Apple Cinema 30&quot;" title="Apple Cinema 30&quot;" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Apple Cinema 30&quot;</a></h4>
                                            <p class="price"> <span class="price-new">$110.00</span> <span class="price-old">$122.00</span> <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/canon_eos_5d_1-200x200.jpg" alt="Canon EOS 5D" title="Canon EOS 5D" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Canon EOS 5D</a></h4>
                                            <p class="price"> <span class="price-new">$98.00</span> <span class="price-old">$122.00</span> <span class="saving">-20%</span> </p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/imac_1-200x200.jpg" alt="iMac" title="iMac" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">iMac</a></h4>
                                            <p class="price"> <span class="price-new">$92.00</span> <span class="price-old">$122.00</span> <span class="saving">-25%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/macbook_air_1-200x200.jpg" alt="MacBook Air" title="MacBook Air" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">MacBook Air</a></h4>
                                            <p class="price"> <span class="price-new">$782.00</span> <span class="price-old">$1,202.00</span> <span class="saving">-35%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-layout">
                                    <div class="product-thumb">
                                        <div class="image"><a href="product.html"><img src="image/product/samsung_tab_1-200x200.jpg" alt="Samsung Galaxy Tab 10.1" title="Samsung Galaxy Tab 10.1" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="product.html">Samsung Galaxy Tab 10.1</a></h4>
                                            <p class="price"> <span class="price-new">$218.00</span> <span class="price-old">$241.99</span> <span class="saving">-10%</span> </p>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick=""><span>Add to Cart</span></button>
                                            <div class="add-to-links">
                                                <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                                                <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- Product End-->

                    <!-- Bigshop Banner
                    ============================================= -->
                    <div class="bigshop-banner">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 moderns"><a href="#"><img src="image/banner/small-banner1-410x170.jpg" alt="sample banner" title="sample banner"></a></div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 moderns"><a href="#"><img src="image/banner/small-banner-410x170.jpg" alt="sample banner 2" title="sample banner 2"></a></div>
                        </div>
                    </div><!-- Bigshop Banner End-->

                    <!-- Brand Logo Carousel
                    ============================================= -->
                    <div id="carousel" class="owl-carousel nxt">
                        <div class="item text-center"> <a href="#"><img src="image/brands/nfl-130x100.png" alt="Palm" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/brands/redbull-130x100.png" alt="Sony" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/brands/sony-130x100.png" alt="Canon" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/brands/cocacola-130x100.png" alt="Apple" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/brands/burgerking-130x100.png" alt="HTC" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/brands/canon-130x100.png" alt="Hewlett-Packard" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/brands/harley-130x100.png" alt="brand" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/brands/dell-130x100.png" alt="brand1" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/brands/disney-130x100.png" alt="brand1" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/brands/nintendo-130x100.png" alt="brand1" class="img-responsive" /></a> </div>
                    </div><!-- Brand Logo Carousel End -->

                </div><!--Middle Part End-->

            </div>
        </div>
    </div><!--Content End-->

    <!-- Feature Box
    ============================================= -->
    <div class="container">
        <div class="custom-feature-box row">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="feature-box fbox_1">
                    <div class="title">Free & Easy Return</div>
                    <p>Free return in 7 Days after purchasing</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="feature-box fbox_2">
                    <div class="title">Free Shipping</div>
                    <p>Free shipping on order over $1000</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="feature-box fbox_3">
                    <div class="title">Gift Cards</div>
                    <p>Give the special perfect gift</p>
                </div>
            </div>
        </div>
    </div><!-- Feature Box End-->
</div>
    @include('layouts.footer')