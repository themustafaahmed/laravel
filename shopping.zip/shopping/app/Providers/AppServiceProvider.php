<?php

namespace App\Providers;

use App\Http\Controllers\CartController;
use App\Http\Controllers\MiniCartController;
use App\Models\Categories;
use App\Models\Products;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\ServiceProvider;


class AppServiceProvider extends ServiceProvider
{


    protected $listen = ['App\Events\SendOrderMail'
    =>[
        'App\Listeners\SendOrderMail'
        ],
    ];
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot ()
    {
        Schema::defaultStringLength(191);


        //dd($var);
        view()->composer('*', function ($view) {
            $miniCart = new MiniCartController();
            $var = $miniCart->miniCart();
            $view->with('miniCart', $var['miniCart'])
                ->with('allProducts', $var['allProducts'])
                ->with('totalPrice', $var['totalPrice'])
                ->with('categoriesAll', Categories::where('categoryId', '0')->get())
                ->with('productsAll', Products::all());
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register ()
    {
        //
    }
}
