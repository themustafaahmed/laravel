<?php

namespace App\Providers;

use App\Http\Controllers\CartController;
use App\Models\Categories;
use App\Models\Products;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\ServiceProvider;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot ()
    {
        Schema::defaultStringLength(191);

        view()->composer('*', function ($view) {
            $cart = new CartController();
            $session = Session::get('cart');
            $minicart = null;
            if ($session != null) {
                $products = Products::whereIn('id', $session)->get();
                $minicart = $cart->add($session, $products);
            }
            $allProducts = null;
            $totalPrice = null;
            if ($minicart != null) {
                foreach ($minicart as $item) {
                    $allProducts += $item['quantity'];
                    $totalPrice += $item['item']->price * $item['quantity'];
                }
            }
            // dd($all);

            $view->with('minicart', $minicart)
                ->with('allProducts', $allProducts)
                ->with('totalPrice', $totalPrice)
                ->with('categoriesAll', \App\Models\Categories::where('categoryId', '0')->get())
                ->with('productsAll', \App\Models\Products::all());
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register ()
    {
        //
    }
}
