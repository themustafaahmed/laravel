<?php

namespace App\Http\Middleware;

use Closure;
use  \Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class RolesMiddleware
{

    public function handle($request, Closure $next)
    {
       if(Auth::check()){
           $roleId = Auth::user()->role();

           $role = DB::table('roles')
               ->where('Id', '=', $roleId)->first();
           $adminRole = (array)$role;

           if (Auth::check() && $adminRole['roleName'] == "Admin") {
               return $next($request);
           }
       }
        return redirect('/');
    }
}
