<?php

namespace App\Http\Controllers;

use App\Models\Slider;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function index()
    {
        $sliders = Slider::where('show',true)->get();;
        return view('index')->with('sliders',$sliders);
    }
}
