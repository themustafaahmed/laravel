<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Orders;
use App\Models\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class CheckoutController extends Controller
{
    public function checkout(){
        $session = Session::get('cart');
        if ($session != null) {


            $products = Products::whereIn('id', $session)->get();
            $carts = $this->add($session, $products);
           // $cart = $this->cartSet($carts);
           // dd($cart);
        }

        return view('checkout.checkout')->with('carts',$carts);
    }

    public function checkoutPost(Request $request){

        $request->validate([
            'FirstName' => 'required',
            'LastName'=>'required',
            'Telephone' => 'required',
            'Address1'=>'required',
            'Email' => 'required',
            'City'=>'required',
            'Postcode'=>'required',
        ]);
        $session = Session::get('cart');
        $products = Products::whereIn('id', $session)->get();
        $carts = $this->add($session, $products);
        $cart = $this->cartSet($carts);
        $orders =  new Orders();
        $orders->FirstName = $request->get('FirstName');
        $orders->LastName = $request->get('LastName');
        $orders->Telephone = $request->get('Telephone');
        $orders->Address1 = $request->get('Address1');
        $orders->Address2 = $request->get('Address2');
        $orders->Email = $request->get('Email');
        $orders->Postcode = $request->get('Postcode');
        $orders->Fax = $request->get('Fax');
        $orders->Company = $request->get('Company');
        $orders->City = $request->get('City');
        $orders->Country = $request->get('Country');
        $orders->Region = $request->get('Region');
        $orders->userId = $request->get('UserId');
        $orders->isActive = true;
        $orders->Comments = $request->get('Comments');
        $orders->save();
        $orders->cart()->saveMany($cart);

       // return dd($request);
    }

    public function cartSet ($cart)
    {
        $carts = null;
        $index = 0;
        foreach ($cart as $item) {
            $cartItems = new Cart();
            $cartItems->quantity = $item['quantity'];
            $cartItems->productId = $item['id'];
            $cartItems->Total = $item['item']->price * $item['quantity'];
            $carts[$index] = $cartItems;
            $index++;
        }
        return $carts;
    }

    public function add ($session, $products)
    {
        $cartItem = [];
        $index = 0;
        foreach ($products as $product) {
            $cartItem[$index] = ['id' => $product['id'], 'item' => $product, 'quantity' => 0];
            $index++;
        }
        foreach ($session as $item) {
            $index = 0;
            foreach ($cartItem as $cart) {
                if ($item == $cart['id']) {
                    $cartItem[$index]['quantity']++;
                }
                $index++;
            }
        }
        return $cartItem;
    }
}
