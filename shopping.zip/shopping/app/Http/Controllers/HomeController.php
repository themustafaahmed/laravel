<?php

namespace App\Http\Controllers;

use App\Models\Roles;
use App\Models\Slider;
use Illuminate\Http\Request;

class HomeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index()
    {

        return view('profile');
    }
    public function home()
    {
        $sliders = Slider::where('show',true)->get();;
        return view('index')->with('sliders',$sliders);
    }

}
