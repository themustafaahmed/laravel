<?php

namespace App\Http\Controllers;

use App\Classes\Sales;
use App\Models\Categories;
use App\Models\Coupons;
use App\Models\Products;
use App\Models\Shipping;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class MiniCartController extends Controller
{
    public function miniCart ()
    {
        $cart = new CartController();
        $session = Session::get('cart');
        $miniCart = null;
        if ($session != null) {
            $products = Products::whereIn('id', $session)->get();
            $coupon = Coupons::where('status',true)->get();
            $sale = Sales::sales($products,$coupon);
            if($sale !=null){
                foreach ($sale as $item) {
                    $item->price = $item->price - $item->sale;
                }
            }
            $miniCart = $cart->add($session, $sale);
        }
        $allProducts = null;
        $totalPrice = null;
        if ($miniCart != null) {
            foreach ($miniCart as $item) {
                $allProducts += $item['quantity'];
                $totalPrice += $item['item']->price * $item['quantity'];
            }
        }
        $shipping = Shipping::first();
        return ['miniCart'=>$miniCart,
            'allProducts'=> $allProducts,
            'totalPrice'=> $totalPrice,
            'categoriesAll'=> Categories::where('categoryId', '0')->get(),
            'productsAll'=> Products::all(),
            'shipping'=>$shipping];
//with('miniCart', $miniCart)
//        ->with('allProducts', $allProducts)
//        ->with('totalPrice', $totalPrice)
//        ->with('categoriesAll', Categories::where('categoryId', '0')->get())
//        ->with('productsAll', Products::all());
        }
}
