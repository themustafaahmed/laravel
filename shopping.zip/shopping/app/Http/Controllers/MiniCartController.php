<?php

namespace App\Http\Controllers;

use App\Models\Categories;
use App\Models\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class MiniCartController extends Controller
{
    public function miniCart ()
    {
        $cart = new CartController();
        $session = Session::get('cart');
        $miniCart = null;
        if ($session != null) {
            $products = Products::whereIn('id', $session)->get();
            $miniCart = $cart->add($session, $products);
        }
        $allProducts = null;
        $totalPrice = null;
        if ($miniCart != null) {
            foreach ($miniCart as $item) {
                $allProducts += $item['quantity'];
                $totalPrice += $item['item']->price * $item['quantity'];
            }
        }

        return ['miniCart'=>$miniCart,
            'allProducts'=> $allProducts,
            'totalPrice'=> $totalPrice,
            'categoriesAll'=> Categories::where('categoryId', '0')->get(),
            'productsAll'=> Products::all()];
//with('miniCart', $miniCart)
//        ->with('allProducts', $allProducts)
//        ->with('totalPrice', $totalPrice)
//        ->with('categoriesAll', Categories::where('categoryId', '0')->get())
//        ->with('productsAll', Products::all());
        }
}
