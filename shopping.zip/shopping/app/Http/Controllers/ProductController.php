<?php

namespace App\Http\Controllers;

use App\Models\Products;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function productByIdGet ($id)
    {
        $products = Products::where('id', $id)->get();
        return view('product.product')->with('products', $products);
    }
}
