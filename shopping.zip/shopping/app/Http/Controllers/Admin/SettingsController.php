<?php

namespace App\Http\Controllers\Admin;

use App\Models\Media;
use App\Models\Slider;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SettingsController extends Controller
{
    public function settingsGet(){
        $sliders = Slider::all();
        return view('admin.settings.settings')->with('sliders',$sliders);
    }

    public function sliderGet(){
        $sliders = Slider::all();
        return view('admin.settings.slider.slider')->with('sliders',$sliders);
    }
    public function addSliderPost(Request $request){

        $images = $request->get('Images');
        $slider= new Slider();
        $slider->sliderName = $request->get('sliderName');
        $slider->sliderContent =  $request->get('sliderContent');
        $slider->show = (bool)$request->get('Show');
       // dd($slider);
        $slider->save();

        $slider->media()->attach($images);

        return redirect('/admin/settings/slider');
    }

    public function addSliderGet(){
        $medias = Media::all();
        return view('admin.settings.slider.add')->with('medias',$medias);
    }

    public function deleteSliderGet($id){
        $slider = Slider::findOrFail($id);
        $slider->delete();
        return redirect('/admin/settings/slider');
    }

    public function updateSliderGet($id){
        $sliders = Slider::where('id',$id)->get();
        $medias = Media::all();
        return view('admin.settings.slider.update')
            ->with('sliders',$sliders)
            ->with('medias',$medias);
    }
    public function updateSliderPost(Request $request){
        $images = $request->get('Images');
        $id = $request->get('id');
        $sliderName = $request->get('sliderName');
        $sliderContent =  $request->get('sliderContent');
        $show = (bool)$request->get('Show');

        $slider= new Slider();
        $slider->where('id',$id)->update([
            'sliderName'=> $sliderName,
            'sliderContent' => $sliderContent,
            'show' => $show
        ]);

       // $slider->media()->newPivotStatement()
        //    ->where('id',$id)
        //   ->update($images);

        $slider->media()->wherePivot('id',$id)
            ->updateExistingPivot($id,['mediaId'=>$images]);

        return redirect('/admin/settings/slider');
    }
}
