<?php

namespace App\Http\Controllers\Admin;

use App\Models\Orders;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class OrdersController extends Controller
{
    public function orders(){

       $orders = Orders::all();
        return view('admin.orders.order')->with('orders',$orders);
    }
}
