<?php

namespace App\Http\Controllers\Admin;

use App\Mail\AdMail;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
    public function mail(){


        return view('admin.mail.mail');
    }
    public function send(Request $request){
        $message = $request->input('Mail');
        $to = $request->get('To');
        $subject = $request->get('Subject');
        $from = $request->get('From');

        $data = ['message'=>$message,
                 'to'=>$to,
                 'subject'=>$subject,
                 'from'=>$from];
        Mail::send('admin.mail.message',['data'=>$data],
            function($m)use($data){
                $m->from($data['from'])
                        ->to($data['to'])
                        ->subject($data['subject']);
        });
    }
}
