<?php

namespace App\Http\Controllers\Admin;

use App\Mail\AdMail;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
    public function mail(){


        return view('admin.mail.mail');
    }
    public function send(Request $request){
        $message = $request->input('Mail');
        $to = $request->get('To');
        $subject = $request->get('Subject');
        $from = $request->get('From');
        Mail::to($to)->send(new AdMail($message,$subject,$from));
    }
}
