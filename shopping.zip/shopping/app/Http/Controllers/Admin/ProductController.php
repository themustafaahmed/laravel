<?php

namespace App\Http\Controllers\Admin;

use App\Models\Categories;
use App\Models\Images;
use App\Models\Products;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function index(){
        $products = Products::all();
        return view('admin.product.product')->with('products',$products);
    }

    public function addGet(){
        $categories = Categories::where('categoryId','0')->get();
        return view('admin.product.add')->with('categories',$categories);
    }

    public function addPost(Request $request){

        $images =  $request->file('Images');
        $dbPath = null;
        $index = 0;
        if(!empty($images)){
           foreach ($images as $image){
                $imagePath = $image->getClientOriginalExtension();
                $imageName = $this->random().'.'.$imagePath;
                $image->storeAs('uploads/products',$imageName);
                $dbPath[$index] = $imageName;
                $index++;
            }
            $product = new Products();
            $product->Title = $request->get('Title');
            $product->description = $request->get('Description');
            $product->price = $request->get('Price');
            $product->salePrice = $request->get('SalePrice');
            $product->inStock = $request->get('InStock');
            $product->count = $request->get('Count');
            $product->color = $request->get('Color');
            $product->categoryId = $request->get('CategoryId');
            $product->save();
        }
        return redirect('/admin/product');
    }

    public function random(){
        $str = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        return substr(str_shuffle(str_repeat($str, 50)), 0, 50);
    }
}
