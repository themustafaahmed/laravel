<?php

namespace App\Http\Controllers\Admin;

use App\Models\Media;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class MediaController extends Controller
{
    public function media ()
    {
        $medias = Media::all();
        return view('admin.media.media')->with('medias', $medias);
    }

    public function addMediaGet ()
    {
        return view('admin.media.add');
    }

    public function addMediaPost (Request $request)
    {
        $imgPath = $this->MediaSave($request->file('Images'));
        $image = null;
        foreach ($imgPath as $img){
            $image = $img;
        }
        $media = new Media();
        $media->Title = $request->get('Title');
        $media->Alt = $request->get('Alt');
        $media->Path = $image;
        $media->save();
        return redirect('/admin/media');
    }

    public function random ()
    {
        $str = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        return substr(str_shuffle(str_repeat($str, 36)), 0, 36);
    }

    public function MediaSave ($request)
    {
        $images = $request;
        $path = null;
        $index = 0;
        if (!empty($images)) {
            foreach ($images as $image) {
                $imagePath = $image->getClientOriginalExtension();
                $imageName = $this->random() . '.' . $imagePath;
                $image->move(public_path('uploads/medias'), $imageName);
                $path[$index] = $imageName;
                $index++;

            }
        }
        return $path;
    }
}
