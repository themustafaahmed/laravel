<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class CartController extends Controller
{
    public function cart(){
        $session = Session::get('cart');
        if($session != null) {
            $products = Products::whereIn('id', $session)->get();
            $carts = $this->add($session,$products);

        }else {
            return 'No Item in Cart';
        }
        return view('cart.cart')->with('carts',$carts);
    }


    public function cartAddGet($id){
        Session::push('cart',$id);
    }

    public function cartRemovePost(){
        session_start();

    }
    public function cartCheckOutPost($cart){
        session_start();
        foreach ($cart as $item) {
            $cartItems = new Cart();
            $cartItems->quantity = $item['quantity'];
            $cartItems->productId = $item['id'];
            $cartItems->save();
        }
    }

    public function add($session,$products){
        $cartItem = [];
        $index = 0;
        foreach ($products as $product){
            $cartItem[$index] = ['id'=>$product['id'],'item' => $product,'quantity' => 0];
            $index++;
        }
        foreach($session as $item){
            $index = 0;
            foreach ($cartItem as $cart){
                if($item == $cart['id']){
                    $cartItem[$index]['quantity']++;
                }
                $index++;
            }
        }
        return $cartItem;
    }
}
