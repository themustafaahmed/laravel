<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use PhpParser\Node\Expr\BinaryOp\Identical;

class CartController extends Controller
{
    public function cart(){

        $session = Session::get('cart');
        $products = Products::whereIn('id',$session)->get();
        $itemCount = array_count_values($session);

        $cartItems = null;
        $index = 0;
        $index2 = 0;
        $q[] = null;
        foreach ($products as $product){
            $cart = new Cart();
            foreach ($itemCount as $w) {
                $q[$index2] = $w;
                $index2++;

            }
            break;
            $cart['productId'] = $product;
            $cartItems[$index] = $cart;
            $index++;
        }
        dd($q);


        dd($cartItems);

        return view('cart.cart');
    }


    public function cartAddPost($id){
        Session::push('cart',$id);
    }

    public function cartRemovePost(){
        session_start();

    }
    public function cartCheckOutPost(){
        session_start();

    }
}
