<?php

namespace App\Mail;

use App\Models\Orders;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class AdMail extends Mailable
{
    use Queueable, SerializesModels;

    public $orders;

    public function __construct(Orders $orders)
    {
        $this->orders = $orders;
    }

    public function build()
    {
        return $this->markdown('admin.mail.order');
    }
}
