<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class AdMail extends Mailable
{
    use Queueable, SerializesModels;
    public $message;
    public $subject;
    public $from;
    public function __construct($message,$subject,$from)
    {
        $this->message = $message;
        $this->subject = $subject;
        $this->from = $from;
    }

    public function build()
    {
        return $this->subject($this->subject)
          //  ->from($this->from)
            ->view('admin.mail.message')
            ->with('message',$this->message);
    }
}
