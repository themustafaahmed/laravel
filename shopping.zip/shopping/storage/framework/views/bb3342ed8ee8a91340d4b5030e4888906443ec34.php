
<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Document Wrapper
============================================= -->
<div class="wrapper-box">

    <!-- Header
    ============================================= -->
    <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content
    ============================================= -->
    <div id="container">
        <div class="container">

            <!-- Breadcrumb
            ============================================= -->
            <ul class="breadcrumb">
                <li><a href="index.html"><i class="fa fa-home"></i></a></li>
                <li><a href="cart.html">Shopping Cart</a></li>
                <li><a href="checkout.html">Checkout</a></li>
            </ul><!-- Breadcrumb End-->

            <div class="row">
                <!--Middle Part Start-->
                <div id="content" class="col-sm-12">
                    <h1 class="title">Checkout</h1>
                    <div class="row">

                        <div class="col-sm-4">
                            <?php if(auth()->guard()->guest()): ?>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-sign-in"></i> Create an Account or Login</h4>
                                </div>
                                <div class="panel-body">
                                    <div class="radio">
                                        <label>
                                            <input type="radio" value="register" name="account">
                                            Register Account</label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" checked="checked" value="guest" name="account">
                                            Guest Checkout</label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" value="returning" name="account">
                                            Returning Customer</label>
                                    </div>
                                </div>
                            </div>
                                <?php else: ?>
                                    <?php endif; ?>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-user"></i> Your Personal Details</h4>
                                </div>
                                <div class="panel-body">
                                    <fieldset id="account">
                                        <div class="form-group required">
                                            <label for="input-payment-firstname" class="control-label">First Name</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-firstname" placeholder="First Name"
                                                   value="" name="FirstName">
                                        </div>
                                        <div class="form-group required">
                                            <label for="input-payment-lastname" class="control-label">Last Name</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-lastname"
                                                   placeholder="Last Name" value="" name="LastName">
                                        </div>
                                        <div class="form-group required">
                                            <label for="input-payment-email" class="control-label">E-Mail</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-email" placeholder="E-Mail" value="" name="Email">
                                        </div>
                                        <div class="form-group required">
                                            <label for="input-payment-telephone" class="control-label">Telephone</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-telephone" placeholder="Telephone"
                                                   value="" name="Telephone">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-payment-fax" class="control-label">Fax</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-fax" placeholder="Fax" value="" name="Fax">
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title"><i class="fa fa-book"></i> Your Address</h4>
                                </div>
                                <div class="panel-body">
                                    <fieldset id="address" class="required">
                                        <div class="form-group">
                                            <label for="input-payment-company" class="control-label">Company</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-company" placeholder="Company"
                                                   value="" name="Company">
                                        </div>
                                        <div class="form-group required">
                                            <label for="input-payment-address-1" class="control-label">Address 1</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-address-1" placeholder="Address 1"
                                                   value="" name="Address1">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-payment-address-2" class="control-label">Address 2</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-address-2"
                                                   placeholder="Address 2" value="" name="Address2">
                                        </div>
                                        <div class="form-group required">
                                            <label for="input-payment-city" class="control-label">City</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-city" placeholder="City" value="" name="City">
                                        </div>
                                        <div class="form-group required">
                                            <label for="input-payment-postcode" class="control-label">Post Code</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-postcode" placeholder="Post Code" value=""
                                                   name="Postcode">
                                        </div>
                                        <div class="form-group required">
                                            <label for="input-payment-country" class="control-label">Country</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-postcode" placeholder="Country" value=""
                                                   name="Country">
                                        </div>
                                        <div class="form-group required">
                                            <label for="input-payment-zone" class="control-label">Region / State</label>
                                            <input type="text" class="form-control"
                                                   id="input-payment-postcode" placeholder="Region" value=""
                                                   name="Region">
                                        </div>
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" checked="checked" value="1" name="shipping_address">
                                                My delivery and billing addresses are the same.</label>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><i class="fa fa-truck"></i> Delivery Method</h4>
                                        </div>
                                        <div class="panel-body">
                                            <p>Please select the preferred shipping method to use on this order.</p>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" checked="checked" name="Free Shipping">
                                                    Free Shipping - $0.00</label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="Flat Shipping Rate">
                                                    Flat Shipping Rate - $8.00</label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="Per Item Shipping Rate">
                                                    Per Item Shipping Rate - $150.00</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><i class="fa fa-credit-card"></i> Payment Method</h4>
                                        </div>
                                        <div class="panel-body">
                                            <p>Please select the preferred payment method to use on this order.</p>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" checked="checked" name="Cash On Delivery">
                                                    Cash On Delivery</label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="Bank Transfer">
                                                    Bank Transfer</label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="Paypal">
                                                    Paypal</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><i class="fa fa-ticket"></i> Use Coupon Code</h4>
                                        </div>
                                        <div class="panel-body">
                                            <label for="input-coupon" class="col-sm-3 control-label">Enter coupon code</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="input-coupon" placeholder="Enter your coupon here" value="" name="coupon">
                                                <span class="input-group-btn">
                          <input type="button" class="btn btn-primary" data-loading-text="Loading..." id="button-coupon" value="Apply Coupon">
                          </span></div>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="col-sm-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><i class="fa fa-gift"></i> Use Gift Voucher</h4>
                                        </div>
                                        <div class="panel-body">
                                            <label for="input-voucher" class="col-sm-3 control-label">Enter gift voucher code</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="input-voucher" placeholder="Enter your gift voucher code here" value="" name="voucher">
                                                <span class="input-group-btn">
                          <input type="submit" class="btn btn-primary" data-loading-text="Loading..." id="button-voucher" value="Apply Voucher">
                          </span> </div>
                                        </div>
                                    </div>
                                </div>-->
                                <div class="col-sm-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><i class="fa fa-shopping-cart"></i> Shopping cart</h4>
                                        </div>
                                        <div class="panel-body">
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                    <tr>
                                                        <td class="text-center">Image</td>
                                                        <td class="text-left">Product Name</td>
                                                        <td class="text-left">Quantity</td>
                                                        <td class="text-right">Unit Price</td>
                                                        <td class="text-right">Total</td>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $SubTotal = 0; ?>
                                                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="text-center"><a href="product.html">
                                                                <?php $__currentLoopData = $cart['item']->images->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <img class="img-thumbnail" src="<?php echo e(asset('uploads/products/'
                                                                    .$images->ImagePath)); ?>" alt="" height="50" width="50">
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></a>
                                                        </td>

                                                        <td class="text-left"><a href="product.html">
                                                                <?php echo e($cart['item']['Title']); ?></a>
                                                        </td>
                                                        <td class="text-left">
                                                            <div class="input-group btn-block" style="max-width: 200px;">
                                                            <input type="text" name="quantity" value="<?php echo e($cart['quantity']); ?>" size="1" class="form-control">
                                                            <span class="input-group-btn">
                                                            <button type="submit" data-toggle="tooltip" title="Update"
                                                                    class="btn btn-primary">
                                                                <i class="fa fa-refresh"></i>
                                                            </button>
                                                            <button type="button" data-toggle="tooltip" title="Remove"
                                                                    class="btn btn-danger" onClick="">
                                                                <i class="fa fa-times-circle"></i>
                                                            </button>
                                                            </span>
                                                            </div>
                                                        </td>
                                                        <td class="text-right">$<?php echo e($cart['item']->price); ?></td>
                                                        <td class="text-right">$<?php echo e($cart['item']->price*$cart['quantity']); ?></td>
                                                    </tr>
                                                    <?php $SubTotal += $cart['item']->price*$cart['quantity']; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot>
                                                    <tr>
                                                        <td class="text-right" colspan="4"><strong>Sub-Total:</strong></td>
                                                        <td class="text-right"><?php echo e($SubTotal); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-right" colspan="4"><strong>Flat Shipping Rate:</strong></td>
                                                        <td class="text-right">$5.00</td>
                                                    </tr>
                                                    <!--<tr>
                                                        <td class="text-right" colspan="4"><strong>Eco Tax (-2.00):</strong></td>
                                                        <td class="text-right">$4.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-right" colspan="4"><strong>VAT (20%):</strong></td>
                                                        <td class="text-right">$151.00</td>
                                                    </tr>-->
                                                    <tr>
                                                        <td class="text-right" colspan="4"><strong>Total:</strong></td>
                                                        <td class="text-right">$910.00</td>
                                                    </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><i class="fa fa-pencil"></i> Add Comments About Your Order</h4>
                                        </div>
                                        <div class="panel-body">
                                            <textarea rows="4" class="form-control" id="confirm_comment" name="Comments"></textarea>
                                            <br>
                                            <label class="control-label" for="confirm_agree">
                                                <input type="checkbox" checked="checked" value="1" required="" class="validate required" id="confirm_agree" name="confirm agree">
                                                <span>I have read and agree to the <a class="agree" href="#"><b>Terms &amp; Conditions</b></a></span> </label>
                                            <div class="buttons">
                                                <div class="pull-right">
                                                    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
                                                    <?php if(auth()->guard()->guest()): ?>
                                                        <input type="hidden" name="UserId" value="0">
                                                        <?php else: ?>
                                                        <input type="hidden" name="UserId" value="<?php echo e(Auth::user()->id); ?>">
                                                    <?php endif; ?>
                                                    <input type="button" class="btn btn-primary confirm-order"
                                                           id="button-confirm"
                                                           value="Confirm Order">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Middle Part End -->
            </div>
        </div>
    </div><!--Content End-->

    <!-- Feature Box
    ============================================= -->
    <div class="container">
        <div class="custom-feature-box row">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="feature-box fbox_1">
                    <div class="title">Free & Easy Return</div>
                    <p>Free return in 7 Days after purchasing</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="feature-box fbox_2">
                    <div class="title">Free Shipping</div>
                    <p>Free shipping on order over $1000</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="feature-box fbox_3">
                    <div class="title">Gift Cards</div>
                    <p>Give the special perfect gift</p>
                </div>
            </div>
        </div>
    </div><!-- Feature Box End-->

    <!-- Footer
    ============================================= -->
</div>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>