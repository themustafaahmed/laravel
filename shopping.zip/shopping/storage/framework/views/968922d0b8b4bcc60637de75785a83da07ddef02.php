<?php echo $__env->make('admin.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    <!-- Navigation -->
    <?php echo $__env->make('admin.layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Basic Form Elements
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <form method="POST"
                                      action="/admin/product/add"
                                      enctype="multipart/form-data">

                                    <div class="form-group">
                                        <label>Category</label>
                                        <select class="form-control" name="CategoryId">

                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>">
                                                    <?php echo e($category->categoryTitle); ?></option>

                                                <?php $__currentLoopData = $category->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($subCategory->id); ?>">
                                                        <?php echo e($category->categoryTitle); ?>

                                                        ->
                                                        <?php echo e($subCategory->categoryTitle); ?>

                                                    </option>

                                                    <?php $__currentLoopData = $subCategory->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($subsubCategory->id); ?>">
                                                            <?php echo e($category->categoryTitle); ?>

                                                            ->
                                                            <?php echo e($subCategory->categoryTitle); ?>

                                                            ->
                                                            <?php echo e($subsubCategory->categoryTitle); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Product Title</label>
                                        <input class="form-control" name="Title"
                                               placeholder="Product Title">
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control" name="Description" rows="3"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Price</label>
                                        <input class="form-control" name="Price"
                                               placeholder="Price">
                                    </div>
                                    <div class="form-group">
                                        <label>Sale Price</label>
                                        <input class="form-control" name="SalePrice"
                                               placeholder="Sale Price">
                                    </div>
                                    <div class="form-group">
                                        <label>Count</label>
                                        <input class="form-control" name="Count"
                                               placeholder="Count">
                                    </div>
                                    <div class="form-group">
                                        <label>In Stock</label>
                                        <input class="form-control" name="InStock"
                                               placeholder="In Stock">
                                    </div>
                                    <div class="form-group">
                                        <label>Color</label>
                                        <input class="form-control" name="Color"
                                               placeholder="Color">
                                    </div>
                                    <div class="form-group">
                                        <label>Is Active</label>
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox"
                                                       value=""
                                                       name="IsActive"
                                                >Active
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Images</label>
                                        <input type="file" name="Images[]" multiple>
                                    </div>
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <button type="submit" class="btn btn-default">Save</button>
                                </form>
                            </div>

                            <div class="col-lg-6">

                            </div>
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
    </div>
    <!-- /#wrapper -->
</div>
<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>