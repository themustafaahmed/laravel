<?php echo $__env->make('admin.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    <!-- Navigation -->
    <?php echo $__env->make('admin.layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Basic Form Elements
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <form method="POST"
                                      action="/admin/product/update"
                                      enctype="multipart/form-data">

                                    <div class="form-group">
                                        <label>Category</label>
                                        <select class="form-control" name="CategoryId">

                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>">
                                                    <?php echo e($category->categoryTitle); ?></option>

                                                <?php $__currentLoopData = $category->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($subCategory->id); ?>">
                                                        <?php echo e($category->categoryTitle); ?>

                                                        ->
                                                        <?php echo e($subCategory->categoryTitle); ?>

                                                    </option>

                                                    <?php $__currentLoopData = $subCategory->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($subsubCategory->id); ?>">
                                                            <?php echo e($category->categoryTitle); ?>

                                                            ->
                                                            <?php echo e($subCategory->categoryTitle); ?>

                                                            ->
                                                            <?php echo e($subsubCategory->categoryTitle); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group">
                                        <label>Product Title</label>
                                        <input class="form-control" name="Title"
                                               placeholder="Product Title"
                                                value="<?php echo e($product->Title); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control"
                                         name="Description"
                                         rows="3"><?php echo e($product->description); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Price</label>
                                        <input class="form-control" name="Price"
                                               placeholder="Price"
                                               value="<?php echo e($product->price); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Sale Price</label>
                                        <input class="form-control" name="SalePrice"
                                               placeholder="Sale Price"
                                        value="<?php echo e($product->salePrice); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Count</label>
                                        <input class="form-control" name="Count"
                                               placeholder="Count"
                                               value="<?php echo e($product->count); ?>">
                                    </div>

                                        <div class="form-group">
                                            <label>Is Stock</label>
                                            <div class="checkbox checkbox-success checkbox-inline">
                                                <?php if($product->inStock == true): ?>
                                                <input type="checkbox" name="InStock"
                                                       id="inlineCheckbox2" value="true" checked>
                                                <?php else: ?>
                                                <input type="checkbox" name="InStock"
                                                       id="inlineCheckbox2" value="false" >
                                                <?php endif; ?>
                                                <label for="inlineCheckbox2"> </label>
                                            </div>
                                        </div>
                                    <div class="form-group">
                                        <label>Color</label>
                                        <input class="form-control" name="Color"
                                               placeholder="Color"
                                               value="<?php echo e($product->color); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Is Active</label>
                                        <div class="checkbox checkbox-success checkbox-inline">
                                            <?php if($product->isactive == true): ?>
                                            <input type="checkbox" name="IsActive"
                                                   id="inlineCheckbox3" value="true" checked>
                                            <?php else: ?>
                                            <input type="checkbox" name="IsActive"
                                                   id="inlineCheckbox3" value="false">
                                            <?php endif; ?>
                                            <label for="inlineCheckbox3"> </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img class="img-thumbnail" src="<?php echo e(asset('uploads/products/'
                                        .$image->ImagePath)); ?>" alt="" height="150" width="150">
                                        <input type="hidden" name="OldImage[]" value="<?php echo e($image->ImagePath); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="form-group">
                                        <label>Images</label>
                                        <input type="file" name="Images[]" multiple>
                                    </div>

                                    <input type="hidden" name="Id" value="<?php echo e($product->id); ?>">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <button type="submit" class="btn btn-default">Save</button>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </form>
                            </div>

                            <div class="col-lg-6">

                            </div>
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
    </div>
    <!-- /#wrapper -->
</div>
<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>