<?php echo $__env->make('admin.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    <!-- Navigation -->
    <?php echo $__env->make('admin.layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Add Media
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form method="POST"
                                      action="/admin/media/update"
                                      enctype="multipart/form-data">

                                    <div class="form-group">
                                        <label>Media Title</label>
                                        <input class="form-control" name="Title"
                                               placeholder="Media Title"
                                        value="<?php echo e($media->Title); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Media Alt</label>
                                        <textarea class="form-control"
                                                  name="Alt"
                                                  rows="3"><?php echo e($media->Alt); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Current Image</label>
                                        <?php if($media->Path != null): ?>
                                            <img class="img-thumbnail"
                                                 style="width:250px"
                                                 src="<?php echo e(asset('uploads/medias/'
                                                 .$media->Path)); ?>">
                                        <?php else: ?>
                                            <p>Not Found Image</p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label>Image</label>
                                        <input type="file" name="Images[]" >
                                    </div>
                                    <input type="hidden" name="OldImage"
                                           value="<?php echo e('uploads/medias/'.$media->Path); ?>">
                                    <input type="hidden" name="id" value="<?php echo e($media->id); ?>">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <button type="submit" class="btn btn-default">Save</button>
                                </form>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="col-lg-6">

                            </div>
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
    </div>
    <!-- /#wrapper -->
</div>
<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>