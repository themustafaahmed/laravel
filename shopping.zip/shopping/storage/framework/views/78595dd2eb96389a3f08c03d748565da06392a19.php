<nav id="menu" class="navbar">
    <div class="navbar-header"><span class="visible-xs visible-sm"> Menu <i
                    class="fa fa-align-justify pull-right flip"></i></span></div>
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav">
            <li><a class="home_link" title="Home" href="/">
                    <i class="fa fa-home"></i> </a></li>
            <?php $__currentLoopData = $categoriesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="categories_defu dropdown sub">
                    <a class="dropdown-toggle"
                       href="<?php echo e('/category/'.$category->categoryUrl); ?>"><?php echo e($category->categoryTitle); ?></a>
                    <span class="submore"></span>
                    <?php if($category->subCategory->count() != 0): ?>
                    <div class="dropdown-menu" style="display: none;">
                        <ul>
                            <?php $__currentLoopData = $category->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e('/category/'.$subCategory->categoryUrl); ?>">
                                        <?php echo e($subCategory->categoryTitle); ?>

                                        <?php if($subCategory->subCategory->count() != 0): ?>
                                            <span class="fa fa-caret-right"></span>
                                        <?php endif; ?></a>
                                    <span class="submore"></span>
                                    <div class="dropdown-menu" style="display: none;">
                                        <ul>
                                            <?php $__currentLoopData = $subCategory->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e('/category/'.$subSubCategory->categoryUrl); ?>">
                                                        <?php echo e($subSubCategory->categoryTitle); ?>

                                                        <?php if($subSubCategory->subCategory->count() != 0): ?>
                                                            <span class="fa fa-caret-right"></span>
                                                        <?php endif; ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</nav>