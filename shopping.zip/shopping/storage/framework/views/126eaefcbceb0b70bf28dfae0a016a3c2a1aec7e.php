<div class="col-md-9 pull-right col-sm-4 col-xs-12 inner">
    <div id="cart">
        <button type="button" data-toggle="dropdown" data-loading-text="Loading..." class="heading dropdown-toggle">
            <span class="cart-icon pull-left flip"></span>
            <span id="cart-total">
                <?php echo e($allProducts); ?> item(s)
                - $ <?php echo e($totalPrice); ?>

            </span>
            <i class="fa fa-caret-down"></i></button>
        <ul class="dropdown-menu">
            <li>
                <table class="table">
                    <tbody>
                    <?php $__currentLoopData = $minicart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center">
                            <a href="">
                                <?php $__currentLoopData = $cart['item']->images->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img class="img-thumbnail" src="<?php echo e(asset('uploads/products/'
                                    .$images->ImagePath)); ?>" alt="" height="50" width="50">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </a>
                        </td>
                        <td class="text-left">
                            <a href="product.html"><?php echo e($cart['item']['Title']); ?></a>
                        </td>
                        <td class="text-right">x <?php echo e($cart['quantity']); ?></td>
                        <td class="text-right">$<?php echo e($cart['item']->price); ?></td>
                        <td class="text-center">
                            <button class="btn btn-danger btn-xs remove remove-cart"
                                    title="Remove" type="button" data-id="<?php echo e($cart['id']); ?>">
                                <i class="fa fa-times"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </li>
            <li>
                <div>
                    <table class="table table-bordered">
                        <tbody>
                        <tr>
                            <td class="text-right"><strong>Sub-Total</strong></td>
                            <td class="text-right">$<?php echo e($totalPrice); ?></td>
                        </tr>
                        <tr>
                            <td class="text-right"><strong>Eco Tax (-2.00)</strong></td>
                            <td class="text-right">$4.00</td>
                        </tr>
                        <tr>
                            <td class="text-right"><strong>VAT (20%)</strong></td>
                            <td class="text-right">$188.00</td>
                        </tr>
                        <tr>
                            <td class="text-right"><strong>Total</strong></td>
                            <td class="text-right">$1,132.00</td>
                        </tr>
                        </tbody>
                    </table>
                    <p class="checkout"><a href="/cart" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> View Cart</a>&nbsp;&nbsp;&nbsp;<a href="checkout.html" class="btn btn-primary"><i class="fa fa-share"></i> Checkout</a></p>
                </div>
            </li>
        </ul>
    </div>
</div>