<?php echo $__env->make('admin.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    <!-- Navigation -->
    <?php echo $__env->make('admin.layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Settings</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Basic Form Elements
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <form method="POST"
                                      action="/admin/settings/slider/update"
                                      enctype="multipart/form-data">
                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group">
                                        <label>Slider Name</label>
                                        <input class="form-control" name="sliderName"
                                               placeholder="Slider Title"
                                        value="<?php echo e($slider->sliderName); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Slider Content</label>
                                        <input class="form-control" name="sliderContent"
                                               placeholder="Slider Content"
                                               value="<?php echo e($slider->sliderName); ?>">
                                    </div>
                                    <div class="form-group">
                                    <div class="checkbox checkbox-success checkbox-inline">
                                        <?php if($slider->show == true): ?>
                                        <input type="checkbox" name="Show" id="inlineCheckbox2" value="true" checked>
                                        <?php else: ?>
                                        <input type="checkbox" name="Show" id="inlineCheckbox2" value="false">
                                        <?php endif; ?>
                                        <label for="inlineCheckbox2">Show Slider </label>
                                    </div>
                                    </div>
                                        <div class="form-group">
                                            <label>Images</label>
                                            <?php $__currentLoopData = $slider->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img class="img-thumbnail"
                                                     style="width:100px" src="<?php echo e(asset('uploads/medias/'
                                                                .$media->Path)); ?>">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <div class="form-group">
                                        <label>Select Images</label>
                                        <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="searchable-container">
                                                <div class="items col-xs-5 col-sm-5 col-md-3 col-lg-3">
                                                    <div class="info-block block-info clearfix">
                                                        <div data-toggle="buttons" class="btn-group bizmoduleselect">
                                                            <label class="btn btn-default" >
                                                                <div class="bizcontent">
                                                                    <input type="checkbox" name="Images[]"
                                                                           autocomplete="off"
                                                                           value="<?php echo e($media->id); ?>">
                                                                    <span class="glyphicon glyphicon-ok glyphicon-lg"></span>
                                                                    <img style="width:100px"
                                                                         src="<?php echo e(asset('uploads/medias/'
                                                                        .$media->Path)); ?>">
                                                                </div>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <button type="submit" class="btn btn-default">Save</button>
                                    </div>
                                </form>
                            </div>

                            <div class="col-lg-6">

                            </div>
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
    </div>
    <!-- /#wrapper -->
</div>
<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>