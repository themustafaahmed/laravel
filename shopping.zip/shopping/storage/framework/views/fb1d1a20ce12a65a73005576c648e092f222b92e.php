<?php echo $__env->make('admin.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    <!-- Navigation -->
    <?php echo $__env->make('admin.layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>

                <a href="/admin/product/add" type="button" class="btn btn-success">Add Product</a>
                <h5></h5>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        DataTables Advanced Tables
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>Sale Price</th>
                                <th>In Stock</th>
                                <th>Count</th>
                                <th>Color</th>
                                <th>Category</th>
                                <th>Images</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product->id); ?></td>
                                    <td><?php echo e($product->Title); ?></td>
                                    <td><?php echo e($product->description); ?></td>
                                    <td><?php echo e($product->price); ?></td>
                                    <td><?php echo e($product->salePrice); ?></td>
                                    <td><?php echo e($product->inStock); ?></td>
                                    <td><?php echo e($product->count); ?></td>
                                    <td><?php echo e($product->color); ?></td>
                                    <td><?php echo e($product->categories['categoryTitle']); ?></td>
                                    <td><?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img class="img-thumbnail" src="<?php echo e(asset('uploads/products/'
                                        .$image->ImagePath)); ?>" alt="" height="50" width="50">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>

                                    <td>
                                        <a href="/admin/product/update/<?php echo e($product->id); ?>"
                                           type="button" class="btn btn-info">Update</a>
                                        <a href="/admin/product/delete/<?php echo e($product->id); ?>"
                                           type="button" class="btn btn-danger">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>