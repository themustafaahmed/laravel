<?php echo $__env->make('admin.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    <!-- Navigation -->
    <?php echo $__env->make('admin.layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Send Mail</h1>
                <h5></h5>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

        <div class="row">
            <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
            <input id="btn-input" type="text" class="form-control input-sm"
                   name="Subject" placeholder="Subject">
            <input id="btn-input" type="email" class="form-control input-sm"
                   name="From" placeholder="From">
            <textarea name="Mail" id="editor" rows="10" cols="80"></textarea>
            <div class="panel-footer">
                <div class="input-group">
                    <input id="btn-input" type="email" class="form-control input-sm"
                           name="To" placeholder="Send to ...">
                    <span class="input-group-btn">
                    <button class="btn btn-warning btn-sm send-mail"
                            id="btn-chat"
                            >Send</button>
                    </span>
                    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
                </div>
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->
</div>
<script>
    CKEDITOR.replace( 'editor' );

</script>
<!-- /#wrapper -->
<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>