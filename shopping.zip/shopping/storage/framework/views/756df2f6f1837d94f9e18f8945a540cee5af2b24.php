<?php echo $__env->make('admin.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    <!-- Navigation -->
    <?php echo $__env->make('admin.layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tables</h1>

                <a href="/admin/category/add" type="button" class="btn btn-success">Add Product</a>
               <h5></h5>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        DataTables Advanced Tables
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Category Title</th>
                                <th>Category Url</th>
                                <th>Sub Categories</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($category->id); ?></td>
                                <td><?php echo e($category->categoryTitle); ?></td>
                                <td><?php echo e($category->categoryUrl); ?></td>
                                <td><?php $__currentLoopData = $category->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p>Sub Category Name: <?php echo e($subCategory->categoryTitle); ?></p>
                                        <p>Sub Category Url: <?php echo e($subCategory->categoryUrl); ?></p>
                                        <a href="/admin/category/delete/<?php echo e($subCategory->id); ?>"
                                           type="button" class="btn btn-warning btn-circle">
                                            <i class="fa fa-times"></i></a>
                                        <a href="/admin/category/update/<?php echo e($subCategory->id); ?>"
                                           type="button" class="btn btn-success btn-circle">
                                            <i class="fa fa-edit"></i></a>
                                        <br>
                                        <?php $__currentLoopData = $subCategory->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span>
                                                <p>Sub Sub Category Name: <?php echo e($subSubCategory->categoryTitle); ?></p>
                                                <p>Sub Sub Category Url: <?php echo e($subSubCategory->categoryUrl); ?></p>
                                                <a href="/admin/category/delete/<?php echo e($subSubCategory->id); ?>"
                                                   type="button" class="btn btn-warning btn-circle">
                                                    <i class="fa fa-times"></i></a>
                                                <a href="/admin/category/update/<?php echo e($subSubCategory->id); ?>"
                                                   type="button" class="btn btn-success btn-circle">
                                                    <i class="fa fa-edit"></i></a>
                                                <br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>

                                <td>
                                    <a href="/admin/category/update/<?php echo e($category->id); ?>"
                                       type="button" class="btn btn-info">Update</a>
                                    <a href="/admin/category/delete/<?php echo e($category->id); ?>"
                                       type="button" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>