<?php echo $__env->make('admin.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    <!-- Navigation -->
    <?php echo $__env->make('admin.layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Orders</h1>
                <h5></h5>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        All Orders
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>User</th>
                                <th>FirstName</th>
                                <th>LastName</th>
                                <th>eMail</th>
                                <th>Telephone</th>
                                <th>is Active</th>
                                <th>Fax</th>
                                <th>Company</th>
                                <th>Address1</th>
                                <th>Address2</th>
                                <th>City</th>
                                <th>Country</th>
                                <th>RegionState</th>
                                <th>Postcode</th>
                                <th>Products</th>
                                <th>Order Date</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e($order->userId); ?></td>
                                    <td><?php echo e($order->FirstName); ?></td>
                                    <td><?php echo e($order->LastName); ?></td>
                                    <td><?php echo e($order->eMail); ?></td>
                                    <td><?php echo e($order->Telephone); ?></td>
                                    <td><?php if($order->isActive == true): ?>
                                        <input type="checkbox" name="IsActive"
                                            id="inlineCheckbox3" value="true" checked>
                                        <?php else: ?>
                                        <input type="checkbox" name="IsActive"
                                            id="inlineCheckbox3" value="false">
                                        <?php endif; ?></td>
                                    <td><?php echo e($order->Fax); ?></td>
                                    <td><?php echo e($order->Company); ?></td>
                                    <td><?php echo e($order->Address1); ?></td>
                                    <td><?php echo e($order->Address2); ?></td>
                                    <td><?php echo e($order->City); ?></td>
                                    <td><?php echo e($order->Country); ?></td>
                                    <td><?php echo e($order->RegionState); ?></td>
                                    <td><?php echo e($order->Postcode); ?></td>
                                    <td>
                                    <?php $TotalPrice = 0;?>
                                    <?php $__currentLoopData = $order->cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $item->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p>Product Title: <a href="<?php echo e('/product/'.$product->id); ?>"><?php echo e($product->Title); ?></a></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <p>Product Quantity: <?php echo e($item->quantity); ?></p>
                                        <p>Total: $<?php echo e($item->Total); ?></p>
                                            --------------------
                                        <?php $TotalPrice += $item->Total ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <p>Shipping: <?php if($order->Shipping == null): ?>
                                                     Free
                                                     <?php else: ?>
                                                     $<?php echo e($order->Shipping); ?>

                                                     <?php endif; ?>
                                        </p>
                                        <p>Total Price: $<?php echo e($order->Shipping + $TotalPrice); ?></p>
                                    </td>
                                    <td><?php echo e($order->created_at); ?></td>
                                    <td>
                                        <a href="/admin/product/update/<?php echo e($order->id); ?>"
                                           type="button" class="btn btn-info">Update</a>
                                        <a href="/admin/product/delete/<?php echo e($order->id); ?>"
                                           type="button" class="btn btn-danger">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>