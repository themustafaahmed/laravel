<?php echo $__env->make('admin.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    <!-- Navigation -->
    <?php echo $__env->make('admin.layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="page-wrapper">


    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>