$(function () {
    $(".confirm-order").on("click", function () {
        var UserId = $("[name=UserId]").val();
        var FirstName = $("[name=FirstName]").val();
        var LastName = $("[name=LastName]").val();
        var Telephone = $("[name=Telephone]").val();
        var Address1 = $("[name=Address1]").val();
        var Address2 = $("[name=Address2]").val();
        var Email = $("[name=Email]").val();
        var Postcode = $("[name=Postcode]").val();
        var Fax = $("[name=Fax]").val();
        var Company = $("[name=Company]").val();
        var City = $("[name=City]").val();
        var CountryId = $("[name=CountryId]").val();
        var ZoneId = $("[name=ZoneId]").val();


        // alert(FirstName + " "+LastName+ " "+Telephone +
        //     " "+Address1+ " "+Address2+ " "+Email
        //     + " "+Postcode+ " "+Fax
        //     + " "+Company+ " "+City);
        // var url = "?&FirstName=" + FirstName + "&LastName=" + LastName +
        //     "&Telephone=" + Telephone + "&Address1=" + Address1 + "&Email=" +
        //     Email + "&Postcode=" + Postcode + "&Address2=" + Address2 +
        //     "&Fax=" + Fax + "&Company=" + Company + "&City=" + City +
        //     "&CountryId=" + CountryId + "&ZoneId=" + ZoneId;
        $.ajax({
            type: "POST",
            url: "/cart/checkout",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            },
            data:{

                FirstName:FirstName,
                LastName:LastName,
                Telephone:Telephone,
                Address1:Address1,
                Address2:Address2,
                Email:Email,
                Postcode:Postcode,
                Fax:Fax,
                Company:Company,
                City:City,
                CountryId:CountryId,
                ZoneId:ZoneId,
                UserId:UserId
            },
            success: function (response) {
                //window.location.href = response.redirect = "/cart/checkout";
                console.log(response);
            }
        });
    });
});