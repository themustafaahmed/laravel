$(document).ready(function () {
    $(".isStock").val($product['isStock']);
    alert(num);
});