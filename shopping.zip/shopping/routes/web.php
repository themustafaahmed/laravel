<?php



Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/products','ProductsController@index');



//Admin Routes
Route::get('/admin', 'Admin\AdminController@index')
        ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::get('/admin/category', 'Admin\CategoryController@category')
        ->middleware(\App\Http\Middleware\RolesMiddleware::class);

//Add Category Get
Route::get('/admin/category/add', 'Admin\CategoryController@addGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);
// Add Category Post
Route::post('/admin/category/add', 'Admin\CategoryController@addPost')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

// Update Category Get
Route::get('/admin/category/update/{id?}', 'Admin\CategoryController@updateGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);
//Update Category Post
Route::post('/admin/category/update', 'Admin\CategoryController@updatePost')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

//Delete Category Get
Route::get('/admin/category/delete/{id?}', 'Admin\CategoryController@deleteGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);





