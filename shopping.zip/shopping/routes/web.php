<?php



Route::get('/', function () {
    return view('index') ;
});

Auth::routes();

Route::get('/profile', 'HomeController@index')->name('profile');

Route::get('/product','ProductController@index');



//Admin Routes
Route::get('/admin', 'Admin\AdminController@index')
        ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::get('/admin/category', 'Admin\CategoryController@category')
        ->middleware(\App\Http\Middleware\RolesMiddleware::class);

//Add Category Get
Route::get('/admin/category/add', 'Admin\CategoryController@addGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);
// Add Category Post
Route::post('/admin/category/add', 'Admin\CategoryController@addPost')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

// Update Category Get
Route::get('/admin/category/update/{id?}', 'Admin\CategoryController@updateGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);
//Update Category Post
Route::post('/admin/category/update', 'Admin\CategoryController@updatePost')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

//Delete Category Get
Route::get('/admin/category/delete/{id?}', 'Admin\CategoryController@deleteGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);


Route::get('/admin/product', 'Admin\ProductController@index')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::get('/admin/product/add', 'Admin\ProductController@addGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::post('/admin/product/add', 'Admin\ProductController@addPost')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::get('/admin/product/update/{id?}', 'Admin\ProductController@updateGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::post('/admin/product/update', 'Admin\ProductController@updatePost')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::get('/admin/product/delete/{id?}', 'Admin\ProductController@deleteGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::get('/admin/settings', 'Admin\SettingsController@settingsGet')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::post('/admin/settings/slider', 'Admin\SettingsController@addSliderPost')
    ->middleware(\App\Http\Middleware\RolesMiddleware::class);

Route::get('/category/{title?}', 'CategoryController@categoryGet');

Route::get('/cart', 'CartController@cart');

Route::get('/cart/add/{id?}', 'CartController@cartAddGet');

Route::get('/cart/remove/{id?}', 'CartController@cartRemoveGet');

Route::get('/cart/update/{id?}/{quantity?}', 'CartController@cartUpdateGet');

Route::get('/cart/qty/{id?}/{quantity?}', 'CartController@addCartWithQtyGet');

Route::get('/product/{id?}', 'ProductController@productByIdGet');